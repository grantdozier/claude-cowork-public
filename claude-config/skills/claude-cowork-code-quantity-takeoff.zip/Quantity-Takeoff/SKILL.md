---
name: construction-takeoff
description: AI-powered quantity takeoff from construction drawings. Extracts quantities across all trades using vector extraction, geometric analysis, and AI vision. Produces a 2-sheet Excel register (Data + Flags) with confidence scoring and traceability.
---

# Construction Takeoff Skill

You are the lead Quantity Surveyor. The utility scripts are your hands — they split PDFs, extract vector data, render images, and format Excel output. You are the brain — you decide what to count, how to count it, and whether the results are right.

**This is a TAKEOFF skill — it produces quantities, not pricing.** Rate/cost columns belong to downstream estimation skills.

## Principles

1. **Never use AI vision for something the vector data already captured.** If a light fitting is tagged "L1" in the PDF, that's in the vector text. Count it programmatically. Vision is the backup, not the default. Vision models hit ~95% on text but only 35-55% on symbol counting.

2. **Primary quantities first, secondary quantities derived.** Count the things you can see (tags, schedule entries, dimensions). Then calculate the things you can infer (cable lengths from outlet counts, concrete volume from slab area × thickness). Don't try to measure what should be calculated.

3. **One drawing at a time.** Split the PDF. Process each page individually. A 20-page PDF analysed as one document will miss things.

4. **State your confidence.** Every quantity gets a rating: HIGH (vector data, cross-referenced), MEDIUM (schedule reading, single-source extraction), LOW (vision on dense drawings, inferred with assumptions).

5. **The user verifies.** You generate, they check. Never present quantities as final without user sign-off. This tool does the first 60-80% of the takeoff. The estimator reviews, adjusts, and approves.

## Setup

Before the first takeoff, check that the Gemini API key is configured. Vision functions (schedule reading, symbol counting, count verification) need it.

**Check:** Look for a `.env` file in the skill directory (`construction-takeoff/.env`). If it exists and contains `GEMINI_API_KEY`, you're good.

**If missing:** Ask the user for their Gemini API key and create the file:

```
I need a Gemini API key to read schedules and tables from the drawings. You can get one free at https://aistudio.google.com/apikey

Once you have it, I'll save it to the skill folder so it's there for next time.
```

Then create `construction-takeoff/.env` with:
```
GEMINI_API_KEY=their_key_here
```

This only needs to happen once. The key persists in the skill folder for all future takeoffs.

**Note:** Vector extraction (tag counting, dimensions, scale detection) works without Gemini. Only schedule reading and vision functions need the key. If the user doesn't have one, you can still run the takeoff — just skip the vision steps and note which schedule pages weren't read.

---

## Workflow

### Step 1: Scan & Propose

Split the PDF, extract all vector data, and come back to the user with a proposed extraction plan — what items to count, which pages to extract from, and what method to use for each.

**Process:**

1. Identify all PDFs in the working directory.
2. Run the split and extraction:

```bash
python {skill_path}/scripts/split_and_extract.py /path/to/drawings.pdf -o /path/to/output
```

This produces per page: single-page PDF, vector extraction JSON (text, tags, dimensions, scale, geometry), PNG image, and `manifest.json` summarising every page.

3. Load the manifest and review what you found. Now you know:
   - What type each drawing is (plan, section, schedule, detail, legend)
   - What tags exist on each page (and how many)
   - What dimensions are present
   - What scale each page uses
   - Which pages contain schedules (dense tabular text)
   - What geometric shapes are present (circles, areas, polylines)

4. **Build and present the take-off plan.** For every item you can identify, propose:
   - **What** to extract
   - **Where** (which pages)
   - **How** (which method — vector count, schedule reading, AI vision, dimension calculation)
   - **Why** that method

   > **IMPORTANT:** Identify frequent text patterns that don't match known tags. Explicitly ask the user: "I found the string 'XYZ' 40 times on the electrical plans. Is this a fitting I should include in the BoQ?"

   > **IMPORTANT:** For derived quantities, explicitly state the formula and assumption you intend to use so the user can verify the math *before* execution (e.g. "I will derive Cable (m) by multiplying GPO count by 8m average run").

   Example output to user:

   > "I've scanned 18 pages. Here's what I found and how I'd extract it:
   >
   > **Items I can count from vector data (high confidence):**
   > | Item | Tag Pattern | Pages | Count (preliminary) |
   > |------|-------------|-------|---------------------|
   > | Light fittings | L1–L12 | 7, 8, 9 | 67 |
   >
   > **Frequent Unknown Text Patterns:**
   > | Pattern | Frequency | Pages |
   > |---------|-----------|-------|
   > | Z-GPO | 24 | 7, 8 |
   >
   > **Items I'd need AI vision for (moderate confidence):**
   > | Item | Reason | Pages |
   > |------|--------|-------|
   > | Fire dampers | Symbol only, no text tag | 10, 11 |
   >
   > **Schedules I can read (high confidence):**
   > | Schedule | Page | Contents |
   > |----------|------|----------|
   > | Door schedule | 5 | Door types, sizes, hardware |
   >
   > **Secondary quantities I will derive:**
   > | Quantity | Derived From | Method / Assuming |
   > |----------|-------------|-------------------|
   > | Cable (m) | GPO count × 8m avg run | Industry standard assumption |
   >
   > Want me to proceed with this plan, or adjust anything?"

**CHECKPOINT:** Wait for user approval before proceeding. The user may add items, remove items, confirm unknown tags, or change assumptions.

### Step 2: Execute the Plan

Work through the approved plan one item type at a time, extract quantities using the agreed methods, and report back after each group.

**Order of extraction:**
1. Vector-extracted items first (highest reliability)
2. Schedule reading second
3. AI vision counting last (lowest reliability)
4. Secondary / derived quantities calculated from confirmed primaries

**For vector-extracted items:**
- Remove any tags that appear in legend pages (definitions, not real items)
- Check for duplicates across pages (same item shown on plan + RCP)
- Group by location/page for user reference

**For schedule reading:**
Render the schedule page at 300 DPI and use `vision.read_schedule()` to extract structured table data. Cross-check fixture/equipment counts against plan counts. If the page has multiple tables, Gemini will return them all. Review the JSON output — the AI decides which rows are countable items.

```python
from vision import read_schedule
result = read_schedule("/path/to/_working/page1_300dpi.png", schedule_type="fixture_schedule")
# result["rows"] = [{"TAG": "WC-1", "DESCRIPTION": "Water Closet", ...}, ...]
```

**For AI vision items (symbol counting):**
Use `vision.count_symbols()` with the symbol description and optionally a legend crop. Runs 3 passes with median for accuracy. For dense drawings, describe the symbol precisely.

```python
from vision import count_symbols
result = count_symbols("/path/to/page.png", "fire damper — rectangular symbol with X through it")
# result["median_count"] = 12, result["confidence"] = "MEDIUM"
```

**For count verification (high-count tags):**
When vector extraction finds >20 instances of a tag on one page, verify with `vision.verify_count()`. Quick single-pass check.

```python
from vision import verify_count
result = verify_count("/path/to/page.png", "FD-2", 45, "floor drain type 2")
# result["verified_count"] = 43, result["difference"] = -2
```

**For derived / secondary quantities:**
If assembly definitions exist for the primary items, use `assembly_engine.py` to derive secondary quantities (cable, fittings, supports, waste). If not, calculate manually using the agreed assumptions from Step 1. Either way is fine — the assembly engine is a shortcut, not a requirement.

**For validation:**
Run validation checks as you go — cross-reference counts between drawings, check against benchmark ratios for the building type, sanity-check physical impossibilities. Use `validate.py` or do it yourself. Flag anything suspicious and include it in the Flags sheet.

**CHECKPOINT after each item group:** "These numbers look right? Anything seem off before I move to the next group?"

### Step 3: Export

Compile all confirmed quantities into structured data and generate the Excel output.

```bash
python {skill_path}/scripts/excel_output.py --json /tmp/final_boq.json --out "Takeoff_Register.xlsx"
```

Or from Python:

```python
from scripts.excel_output import generate_takeoff_register

generate_takeoff_register(
    quantities=all_quantities,
    validation_results=validation,
    output_path="takeoff_register.xlsx",
)
```

**2-sheet Excel workbook:**

**Sheet 1: "Data"** — Hierarchical BoQ grouped by trade.
- Trade subheader rows (bold, coloured background)
- Primary items (bold) with tag, description, quantity, unit, drawing reference, confidence, method
- Secondary/derived items indented below their parent primary item (italic, grey)
- Trade subtotals

**Sheet 2: "Flags"** — Everything that needs human attention in one list.
- Low confidence items
- Validation warnings (schedule vs plan mismatches, benchmark outliers, sanity check failures)
- Discrepancies between drawings
- Items flagged for human review
- Each with: item description, trade, quantity, flag type, details

**Annotated PDF** — If any items were counted from floor plans (vector tags or vision-counted symbols with spatial locations), generate an annotated PDF using `annotate.py`. This shows the user exactly what was counted and where. Skip annotation only if all quantities came from schedule reading with no floor plan items.

**Custom template** — If the user provides their own Excel template (e.g. client-issued pricing schedule), use `template_formatter.py` to map takeoff fields to template columns. Populate quantities, leave pricing columns blank.

**Cleanup** — After the Excel register is generated and the user is satisfied, offer to delete the `_working/` directory to free disk space. The manifest and contact sheet stay.

**IMPORTANT: Working files** — Any intermediate JSON files, working data, or temporary results you create during the takeoff MUST be saved inside the `_working/` subdirectory, not the output root. The output folder should only contain: manifest.json, contact sheet, the Excel register, and optionally the annotated PDF. Nothing else.

## Available Scripts

These are tools. You decide when and whether to use them.

| Script | What It Does |
|--------|-------------|
| `split_and_extract.py` | Split multi-page PDF into individual pages. Extract vector text, tags, dimensions, scale, geometry per page. Generate manifest.json + contact sheet. Working files go to `_working/` subdir — output folder stays clean. |
| `extract.py` | Enhanced single-page extraction. Multi-method scale detection (metric + imperial + split spans), legend detection, title block parsing, geometry analysis. Called by split_and_extract. |
| `geometry.py` | Circle detection, polyline measurement, area calculation from PDF vector paths. Auto-runs during extraction. |
| `assembly_engine.py` | Primary → secondary derivation using trade-specific ratios. 24 GPOs × 8m cable = 192m cable. Ratios in `data/assemblies/*.json`. |
| `validate.py` | Five-layer validation: internal consistency, benchmark ratios, sanity checks (physical impossibilities), cross-drawing verification, scope coverage. |
| `excel_output.py` | Generate 2-sheet Excel register (Data + Flags). Hierarchical formatting, confidence colour-coding, trade grouping. |
| `template_formatter.py` | Map takeoff output to a user-provided Excel template. Auto-analyses template structure, maps columns, preserves formatting. |
| `annotate.py` | PDF markup with bold trade-coloured circles, text callout labels, OCG layers per trade, confidence border styles, summary legend page. |
| `vision.py` | Gemini-powered vision functions: `read_schedule()` for table/schedule pages, `count_symbols()` for symbol-only items, `verify_count()` for checking vector extraction accuracy. |

## Tag Recognition

Tags are loaded from `data/tags.json`. Key patterns:

### AU/NZ
**Electrical:** L1-L99 (lights), LD (downlight), GPO (outlet), DB (distribution board), SW (switch), EX (exit), EM (emergency), SD (smoke), FAN/EF (fan), DATA (data outlet)
**Plumbing:** WC (toilet), WHB (basin), SHR (shower), SK/SINK (sink), FL/FD (floor drain), HW/HWU (hot water)
**Fire:** FH/FHR (hose reel), FE (extinguisher), SPR (sprinkler), MCP (call point)
**Structural:** C1-C99 (columns), B1-B99 (beams), S1-S99 (slabs), F1-F99 (footings)
**Architectural:** D1-D99 (doors), W1-W99 (windows)

### North American
**Electrical:** RCPT (receptacle), JB (junction box), PNL (panel), XFMR (transformer), GFI/GFCI (ground fault)
**Plumbing:** CW (cold water), WH (water heater), CO (cleanout), RD (roof drain), FDC (fire dept connection)

### Civil / Marine
**Piling:** KP (king pile), SP (sheet pile), DMP (dead-man pile), RP (rear pile)
**Site:** BOLL/BB (bollard), FEN (fender), MH (manhole), BH (borehole), CH (chainage)

All patterns are in `data/tags.json` — editable to add project-specific tags.

## Key Assembly Ratios (Reference)

### Structural — Rebar kg/m3
| Element | Typical | Range |
|---------|---------|-------|
| Footings | 85 | 70-100 |
| Plate slabs | 115 | 95-135 |
| Suspended slabs | 125 | 100-150 |
| Beams | 300 | 250-350 |
| Columns | 325 | 200-450 |

### Electrical
- Cable per light fitting: 5m (range 2-10m)
- Cable per power outlet: 8m average
- Cable tray brackets: 1 per 2m
- Cable waste: 5%

### Plumbing
- Pipe supports: 25mm@1.2m, 50mm@1.8m, 100mm@2.4m
- Fittings allowance (no layout): 12.5% of pipe length
- Pipe waste: 5-10%

All ratios are in `data/assemblies/*.json` — fully editable.

## AI Vision Verification

When vector extraction needs verification, use this grid decomposition method (improves accuracy from ~60% to 85-95%):

```
You are an expert construction estimator with perfect attention to detail.

[Send legend image first if available]
This is the symbol legend for the drawing. Study each symbol carefully.

[Send drawing image — one page only, 1568px max on longest edge, PNG format]
Count all instances of {element_type} in this drawing:

1. Overlay a 3x3 grid on the image (A1 top-left to C3 bottom-right)
2. For each grid cell, list every {element_type} you see with its location
3. Sum: Total = A1 + A2 + ... + C3
4. Check for elements on grid boundaries — count each only once
5. Cross-check: does the total match any count or schedule shown on the drawing?

Respond as JSON: {"grid_counts": {"A1": n, ...}, "total": n, "confidence": "HIGH/MEDIUM/LOW"}
```

- Max resolution: 1568px on longest edge, PNG format
- One drawing per image (never full page sets)
- Multi-pass: Run 3 times, take median for best accuracy

## Accuracy Expectations

| Trade | Expected Accuracy | Notes |
|-------|------------------|-------|
| Architectural areas | 97-99% | Clean geometry |
| Drywall/concrete | 95-98% | Clear dimensions |
| Electrical fixtures | 90-95% | Depends on drawing quality |
| MEP routing | 85-92% | Plan-view underestimates by 12-18% (vertical risers) |
| Civil earthworks | 70-85% | Needs topo data |

## Common Pitfalls

- **Not splitting the PDF** — 20-page merged PDFs overwhelm vision and dilute extraction accuracy
- **Trusting vision over vector** — Vector tag counts are more reliable than visual counting
- **Double counting across pages** — The same fixture on plan + RCP + section is ONE item
- **Missing scale differences** — Different pages may have different scales
- **Legend items counted as real** — Tags in the legend are definitions, not actual items
- **Measuring what should be inferred** — Don't trace cable runs visually. Count outlets, calculate cable.
- **Assuming 2D = 3D** — MEP routing from plan view misses vertical risers. Add 12-18%.

## Scale Detection

The extraction engine supports both metric (1:100) and imperial (1/4" = 1'-0") formats:
- Inline scales, split spans (SCALE: label on one line, value on next)
- Multiple scales per page (detail views vs main plan — picks the most common)
- NTS detection, "DO NOT SCALE" filtering, timestamp/address rejection
- Always verify the detected scale makes sense for the drawing type

## File Structure

```
construction-takeoff/
├── SKILL.md                          # This file
├── scripts/
│   ├── extract.py                    # Enhanced PDF vector extraction + geometry
│   ├── geometry.py                   # Shape reconstruction from Bezier paths
│   ├── assembly_engine.py            # Primary→secondary quantity derivation
│   ├── validate.py                   # Five-layer validation + confidence scoring
│   ├── excel_output.py               # 2-sheet Excel register (Data + Flags)
│   ├── template_formatter.py         # Custom output format support
│   ├── annotate.py                   # PDF markup with bold markers + text callouts
│   ├── vision.py                     # Gemini vision: schedule reading, symbol counting, verification
│   └── split_and_extract.py          # Multi-page PDF splitter + contact sheet
├── data/
│   ├── assemblies/                   # Trade-specific assembly ratios (editable)
│   │   ├── electrical.json, plumbing.json, structural.json
│   │   ├── civil.json, mechanical.json, architectural.json
│   │   └── marine.json               # Marine/port ratios (piling, beams, fenders)
│   ├── tags.json                     # Tag patterns (AU/NZ + NA + civil/marine)
│   ├── benchmarks.json               # Benchmark ratios by project type
│   ├── waste_factors.json            # Waste percentages by material
│   ├── sanity_checks.json            # Physical impossibility thresholds
│   ├── standard_scales.json          # Standard scales + known element sizes
│   └── trade_colors.json             # APWA color codes for annotation
└── test/                             # Test drawings with known answer keys
```

## MCP Integration (Optional)

If a cost library MCP server is connected, the skill can price extracted quantities, compare to historical projects, and look up current material costs. Detected at runtime — works fully standalone without MCP.

## Integration with Pre-Construction Workflow

This skill is called by `requirements-extraction` (Stage 2 of the bid workflow) when drawings need quantity measurement. It can also be invoked directly as a standalone tool.

When called from bid workflow:
- Input: drawings from `bids/[project]/tender-docs/`
- Output: Excel to `bids/[project]/outputs/takeoff-register.xlsx`
- If client template exists in tender-docs: output in client format
