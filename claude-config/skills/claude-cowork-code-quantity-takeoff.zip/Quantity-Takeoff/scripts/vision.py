#!/usr/bin/env python3
"""
Gemini Vision Functions for Construction Takeoff

Three focused functions that give the AI better eyes when vector extraction
isn't enough:

  read_schedule(image_path)    — Parse schedule/table pages into structured JSON
  count_symbols(image_path)    — Count symbol instances via grid decomposition
  verify_count(image_path)     — Quick verification of vector extraction counts

These are tools the AI calls when it decides vision is needed — not a pipeline.
Claude stays as the QS brain; Gemini is the specialist vision tool.

Usage:
    from vision import read_schedule, count_symbols, verify_count

    # Read a fixture schedule
    result = read_schedule("/path/to/schedule_page.png")

    # Count fire dampers
    result = count_symbols("/path/to/floor_plan.png", "fire damper — rectangular with X")

    # Verify FD-2 count
    result = verify_count("/path/to/floor_plan.png", "FD-2", 45)
"""

import os
import sys
import json
import re
from statistics import median

# Load GEMINI_API_KEY from .env
# Checks: skill directory first (construction-takeoff/.env), then cwd
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_SKILL_DIR = os.path.dirname(_SCRIPT_DIR)
try:
    from dotenv import load_dotenv
    # Skill-level .env takes priority (persists across sessions)
    _skill_env = os.path.join(_SKILL_DIR, ".env")
    if os.path.exists(_skill_env):
        load_dotenv(_skill_env)
    else:
        load_dotenv()  # Falls back to cwd/.env
except ImportError:
    pass

try:
    from google import genai
    from google.genai import types
except ImportError:
    print("ERROR: google-genai required. Install with: pip install google-genai", file=sys.stderr)
    sys.exit(1)

try:
    from PIL import Image
except ImportError:
    print("ERROR: Pillow required. Install with: pip install Pillow", file=sys.stderr)
    sys.exit(1)


# ── Configuration ──

DEFAULT_MODEL = "gemini-2.5-flash"
MAX_IMAGE_EDGE = 4096  # Max image edge for Gemini — construction drawings need high res

PRICING = {
    "gemini-2.5-flash": {"input": 0.15, "output": 0.60},
    "gemini-2.5-pro": {"input": 1.25, "output": 10.00},
}


# ── Internal Utilities ──

_client = None

def _init_client():
    """Singleton Gemini client initialization."""
    global _client
    if _client is None:
        api_key = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            raise RuntimeError("GEMINI_API_KEY not set. Add it to .env or set as environment variable.")
        _client = genai.Client(api_key=api_key)
    return _client


def _load_image(path, max_edge=MAX_IMAGE_EDGE):
    """Load a PIL Image, resizing if needed to stay within API limits."""
    img = Image.open(path)
    w, h = img.size
    if max(w, h) > max_edge:
        ratio = max_edge / max(w, h)
        new_size = (int(w * ratio), int(h * ratio))
        img = img.resize(new_size, Image.LANCZOS)
    return img


def _call_gemini(contents, model=DEFAULT_MODEL, max_tokens=8192, temperature=0.2):
    """Call Gemini with error handling and token tracking.

    Args:
        contents: list of text/image items to send
        model: Gemini model name
        max_tokens: max output tokens
        temperature: generation temperature

    Returns:
        dict with text, input_tokens, output_tokens, cost_usd
    """
    client = _init_client()

    config = types.GenerateContentConfig(
        max_output_tokens=max_tokens,
        temperature=temperature,
        http_options=types.HttpOptions(timeout=120_000),
    )

    try:
        response = client.models.generate_content(
            model=model,
            contents=contents,
            config=config,
        )

        text = response.text or ""
        input_tokens = response.usage_metadata.prompt_token_count or 0
        output_tokens = response.usage_metadata.candidates_token_count or 0

        model_pricing = PRICING.get(model, PRICING[DEFAULT_MODEL])
        cost = (
            input_tokens * model_pricing["input"] / 1_000_000
            + output_tokens * model_pricing["output"] / 1_000_000
        )

        return {
            "text": text,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cost_usd": round(cost, 6),
            "model": model,
        }

    except Exception as e:
        return {
            "text": "",
            "error": str(e),
            "input_tokens": 0,
            "output_tokens": 0,
            "cost_usd": 0,
            "model": model,
        }


def _parse_json_response(text):
    """Extract JSON from Gemini response text.

    Handles:
    - Responses wrapped in markdown code blocks (```json ... ```)
    - Raw JSON
    - Truncated JSON (missing closing braces) — attempts repair
    """
    # Try to find JSON in code blocks first
    match = re.search(r'```(?:json)?\s*\n?(.*?)\n?```', text, re.DOTALL)
    if match:
        text = match.group(1).strip()

    # Try parsing as JSON
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try to find the first { ... } or [ ... ] block
    for start_char, end_char in [('{', '}'), ('[', ']')]:
        start = text.find(start_char)
        if start >= 0:
            depth = 0
            for i, c in enumerate(text[start:], start):
                if c == start_char:
                    depth += 1
                elif c == end_char:
                    depth -= 1
                if depth == 0:
                    try:
                        return json.loads(text[start:i+1])
                    except json.JSONDecodeError:
                        break

    # Attempt to repair truncated JSON by closing open braces/brackets
    json_start = text.find('{')
    if json_start < 0:
        json_start = text.find('[')
    if json_start >= 0:
        fragment = text[json_start:].rstrip()
        # Remove trailing comma if present
        fragment = fragment.rstrip(',').rstrip()
        # Count open vs close braces/brackets
        open_braces = fragment.count('{') - fragment.count('}')
        open_brackets = fragment.count('[') - fragment.count(']')
        # Close them
        fragment += ']' * open_brackets + '}' * open_braces
        try:
            return json.loads(fragment)
        except json.JSONDecodeError:
            pass

    return None


# ── Public Functions ──

def read_schedule(image_path, schedule_type=None, context_hints=None, model=DEFAULT_MODEL):
    """Read a schedule/table page and return structured row data.

    Sends a high-res page image to Gemini and gets back structured JSON
    with headers, rows, and notes. The AI then decides which rows
    represent countable items.

    Args:
        image_path: path to PNG of the schedule page (ideally 300 DPI)
        schedule_type: optional hint (e.g., "fixture_schedule", "equipment_schedule",
                       "door_schedule", "window_schedule")
        context_hints: optional list of context strings
        model: Gemini model to use

    Returns:
        dict with headers, rows, row_count, notes, tokens, cost
    """
    img = _load_image(image_path)

    prompt = """You are reading a construction drawing schedule/table. Extract every row of data as structured JSON.

"""
    if schedule_type:
        prompt += f"This is a {schedule_type.replace('_', ' ')}.\n\n"

    if context_hints:
        prompt += "Context:\n"
        for hint in context_hints:
            prompt += f"- {hint}\n"
        prompt += "\n"

    prompt += """Return a JSON object with:
- "headers": list of column header strings exactly as they appear on the drawing
- "rows": list of objects, one per data row, mapping header names to cell values
- "notes": list of any footnotes or general notes associated with the schedule
- "schedule_type": your best guess at the schedule type (e.g., "plumbing_fixture_schedule", "door_schedule")

Rules:
- Read EVERY row. Do not summarise or skip rows.
- Preserve exact text from cells (model numbers, sizes, specifications).
- If a cell spans multiple rows, repeat the value for each spanned row.
- Empty cells should be null.
- Numbers should be numbers where clearly numeric (e.g., 120 not "120"), but keep alphanumeric codes as strings (e.g., "WC-1", "3/4\"").
- If the page contains MULTIPLE separate tables/schedules, return them all in a "tables" array, each with its own headers, rows, and notes."""

    result = _call_gemini([prompt, img], model=model, max_tokens=32768, temperature=0.1)

    if result.get("error"):
        return {
            "success": False,
            "error": result["error"],
            "tokens": {"input": result["input_tokens"], "output": result["output_tokens"]},
            "cost_usd": result["cost_usd"],
            "model": result["model"],
        }

    parsed = _parse_json_response(result["text"])

    if parsed is None:
        return {
            "success": False,
            "error": "Failed to parse JSON from Gemini response",
            "raw_response": result["text"][:500],
            "tokens": {"input": result["input_tokens"], "output": result["output_tokens"]},
            "cost_usd": result["cost_usd"],
            "model": result["model"],
        }

    # Handle list response (Gemini returned an array of tables)
    if isinstance(parsed, list):
        tables = parsed
        total_rows = sum(len(t.get("rows", [])) for t in tables if isinstance(t, dict))
        parsed = {"tables": tables}
    elif "tables" in parsed:
        tables = parsed["tables"]
        total_rows = sum(len(t.get("rows", [])) for t in tables)
    else:
        tables = [parsed]
        total_rows = len(parsed.get("rows", []))

    return {
        "success": True,
        "schedule_type": parsed.get("schedule_type", schedule_type or "unknown"),
        "tables": tables,
        "headers": parsed.get("headers", tables[0].get("headers", []) if tables else []),
        "rows": parsed.get("rows", tables[0].get("rows", []) if tables else []),
        "row_count": total_rows,
        "notes": parsed.get("notes", []),
        "tokens": {"input": result["input_tokens"], "output": result["output_tokens"]},
        "cost_usd": result["cost_usd"],
        "model": result["model"],
    }


def count_symbols(image_path, symbol_description, legend_image_path=None,
                  multi_pass=3, model=DEFAULT_MODEL):
    """Count instances of a specific symbol on a drawing page.

    Uses grid decomposition (3x3) with multiple passes and takes the median
    for best accuracy. Optionally sends a legend crop so Gemini knows
    exactly what symbol to look for.

    Args:
        image_path: path to PNG of the drawing page
        symbol_description: what to count (e.g., "fire damper — rectangular with X")
        legend_image_path: optional path to cropped legend PNG showing the symbol
        multi_pass: number of passes for median (default 3)
        model: Gemini model to use

    Returns:
        dict with median_count, counts_per_pass, confidence, grid_counts, tokens, cost
    """
    img = _load_image(image_path)
    legend_img = _load_image(legend_image_path) if legend_image_path else None

    prompt = f"""You are an expert construction estimator counting items on a drawing.

Count all instances of: {symbol_description}

Instructions:
1. Mentally overlay a 3x3 grid on the image (A1 top-left to C3 bottom-right)
2. For each grid cell, count every instance of the described item
3. Sum: Total = A1 + A2 + A3 + B1 + B2 + B3 + C1 + C2 + C3
4. Check for items on grid boundaries — count each only once
5. Cross-check: does the total match any count or schedule shown on the drawing?

Return JSON:
{{
  "grid_counts": {{"A1": n, "A2": n, "A3": n, "B1": n, "B2": n, "B3": n, "C1": n, "C2": n, "C3": n}},
  "total": n,
  "confidence": "HIGH/MEDIUM/LOW",
  "notes": "any observations about the count or difficult areas"
}}"""

    counts = []
    grid_results = []
    total_tokens = {"input": 0, "output": 0}
    total_cost = 0

    for pass_num in range(multi_pass):
        contents = [prompt]
        if legend_img:
            contents.append(f"[Legend showing {symbol_description}]")
            contents.append(legend_img)
        contents.append("[Drawing to count]")
        contents.append(img)

        result = _call_gemini(contents, model=model, max_tokens=1024, temperature=0.3)

        total_tokens["input"] += result.get("input_tokens", 0)
        total_tokens["output"] += result.get("output_tokens", 0)
        total_cost += result.get("cost_usd", 0)

        if result.get("error"):
            continue

        parsed = _parse_json_response(result["text"])
        if parsed and "total" in parsed:
            counts.append(parsed["total"])
            grid_results.append(parsed)

    if not counts:
        return {
            "success": False,
            "symbol": symbol_description,
            "error": "All passes failed",
            "tokens": total_tokens,
            "cost_usd": round(total_cost, 6),
            "model": model,
        }

    median_count = int(median(counts))
    # Pick the grid result closest to the median
    best_grid = min(grid_results, key=lambda g: abs(g["total"] - median_count))

    # Confidence based on agreement
    spread = max(counts) - min(counts)
    if spread == 0:
        confidence = "HIGH"
    elif spread <= max(2, median_count * 0.1):
        confidence = "MEDIUM"
    else:
        confidence = "LOW"

    return {
        "success": True,
        "symbol": symbol_description,
        "counts_per_pass": counts,
        "median_count": median_count,
        "confidence": confidence,
        "grid_counts": best_grid.get("grid_counts", {}),
        "notes": best_grid.get("notes", ""),
        "tokens": total_tokens,
        "cost_usd": round(total_cost, 6),
        "model": model,
    }


def verify_count(image_path, tag, expected_count, tag_description=None, model=DEFAULT_MODEL):
    """Verify a vector extraction count against vision analysis.

    Quick check: "I found N instances of tag X. Does that look right?"

    Args:
        image_path: path to PNG of the page
        tag: the tag text (e.g., "FD-2")
        expected_count: what vector extraction found
        tag_description: optional description (e.g., "floor drain type 2")
        model: Gemini model to use

    Returns:
        dict with verified_count, matches_expected, difference, confidence, tokens, cost
    """
    img = _load_image(image_path)

    desc = f" ({tag_description})" if tag_description else ""
    prompt = f"""You are verifying a quantity count on a construction drawing.

I counted {expected_count} instances of "{tag}"{desc} on this page using automated vector text extraction.

Please verify:
1. Scan the entire drawing for "{tag}" text labels
2. Count how many distinct instances you find (ignore legend definitions — only count items placed on the drawing)
3. Compare to the expected count of {expected_count}

Return JSON:
{{
  "verified_count": n,
  "matches_expected": true or false,
  "difference": n,
  "confidence": "HIGH/MEDIUM/LOW",
  "notes": "any observations — e.g., similar tags that might be confused, items in legend vs on drawing"
}}"""

    result = _call_gemini([prompt, img], model=model, max_tokens=1024, temperature=0.2)

    if result.get("error"):
        return {
            "success": False,
            "tag": tag,
            "expected_count": expected_count,
            "error": result["error"],
            "tokens": {"input": result["input_tokens"], "output": result["output_tokens"]},
            "cost_usd": result["cost_usd"],
            "model": result["model"],
        }

    parsed = _parse_json_response(result["text"])

    if parsed is None:
        return {
            "success": False,
            "tag": tag,
            "expected_count": expected_count,
            "error": "Failed to parse JSON from Gemini response",
            "raw_response": result["text"][:300],
            "tokens": {"input": result["input_tokens"], "output": result["output_tokens"]},
            "cost_usd": result["cost_usd"],
            "model": result["model"],
        }

    verified = parsed.get("verified_count", expected_count)
    return {
        "success": True,
        "tag": tag,
        "expected_count": expected_count,
        "verified_count": verified,
        "matches_expected": parsed.get("matches_expected", verified == expected_count),
        "difference": verified - expected_count,
        "confidence": parsed.get("confidence", "MEDIUM"),
        "notes": parsed.get("notes", ""),
        "tokens": {"input": result["input_tokens"], "output": result["output_tokens"]},
        "cost_usd": result["cost_usd"],
        "model": result["model"],
    }
