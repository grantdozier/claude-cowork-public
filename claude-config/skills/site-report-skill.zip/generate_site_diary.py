#!/usr/bin/env python3
"""
Generate a Daily Site Diary (.docx) from JSON data using a docxtpl template.

Usage:
    echo '{"project": "...", ...}' | python generate_site_diary.py --output report.docx
    python generate_site_diary.py --input data.json --output report.docx

The template (template.docx) must exist in the same directory. Generate it
with: python build_template.py
"""

import argparse
import json
import sys
from pathlib import Path

from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import nsdecls
from docx.oxml import parse_xml
from docxtpl import DocxTemplate

# ── Constants ──

SCRIPT_DIR = Path(__file__).parent
TEMPLATE_PATH = SCRIPT_DIR / "template.docx"
LIGHT_GRAY_HEX = "F3F5F7"
BORDER_GRAY = "D5D8DC"
DARK_TEXT = RGBColor(0x2D, 0x34, 0x36)
FOOTER_GRAY = RGBColor(0x6B, 0x72, 0x80)


# ── Helpers ──

def set_cell_shading(cell, color_hex):
    shading = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{color_hex}"/>')
    cell._tc.get_or_add_tcPr().append(shading)


def set_cell_borders(cell, color=BORDER_GRAY, size="4"):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = parse_xml(
        f'<w:tcBorders {nsdecls("w")}>'
        f'  <w:top w:val="single" w:sz="{size}" w:space="0" w:color="{color}"/>'
        f'  <w:left w:val="single" w:sz="{size}" w:space="0" w:color="{color}"/>'
        f'  <w:bottom w:val="single" w:sz="{size}" w:space="0" w:color="{color}"/>'
        f'  <w:right w:val="single" w:sz="{size}" w:space="0" w:color="{color}"/>'
        f'</w:tcBorders>'
    )
    tcPr.append(tcBorders)


def set_column_widths(table, widths_cm):
    for i, width in enumerate(widths_cm):
        if i < len(table.columns):
            table.columns[i].width = Cm(width)
            for row in table.rows:
                row.cells[i].width = Cm(width)


# ── Data Preparation ──

def prepare_context(data):
    """Transform raw JSON into the template context dict."""
    # Temperature display
    temp_display = ""
    if data.get("temp_high") or data.get("temp_low"):
        temp_display = f"{data.get('temp_high', '')}C / {data.get('temp_low', '')}C"

    # Workforce total hours
    workforce_total = ""
    try:
        hours = [float(w.get("hours", 0)) for w in data.get("workforce", []) if w.get("hours")]
        if hours:
            workforce_total = str(sum(hours))
    except (ValueError, TypeError):
        pass

    # Pad empty lists with one empty-string dict so the template loop produces 1 row
    def pad(items, keys):
        if not items:
            return [{k: "" for k in keys}]
        return items

    visitors = pad(data.get("visitors", []), ["time", "name", "organisation", "purpose"])
    deliveries = pad(data.get("deliveries", []), ["time", "supplier", "material", "quantity", "docket"])
    delays = pad(data.get("delays", []), ["description", "cause", "duration", "impact"])
    workforce = pad(data.get("workforce", []), ["crew_trade", "start", "finish", "hours", "cost_code", "scope_area"])
    work_completed = pad(data.get("work_completed", []), ["task", "quantity", "unit", "area", "notes"])
    rfis = pad(data.get("rfis", []), ["ref", "description", "direction", "status"])

    # Normalize issues into a list of {num, text} dicts
    issues_list = data.get("issues_notes_list", [])
    issues_text = data.get("issues_notes", "")
    if not issues_list and issues_text:
        issues_list = [line.strip() for line in issues_text.split("\n") if line.strip()]
    if not issues_list:
        issues_list = [""]
    issues = [{"num": str(i + 1) if text else "", "text": text} for i, text in enumerate(issues_list)]

    # Safety defaults
    safety = data.get("safety", {})
    safety_ctx = {
        "toolbox_talk": safety.get("toolbox_talk", ""),
        "incidents": safety.get("incidents", ""),
        "observations": safety.get("observations", ""),
        "environmental": safety.get("environmental", ""),
    }

    return {
        "project": data.get("project", ""),
        "report_no": data.get("report_no", ""),
        "date": data.get("date", ""),
        "day": data.get("day", ""),
        "weather": data.get("weather", ""),
        "temp_display": temp_display,
        "site_supervisor": data.get("site_supervisor", ""),
        "prepared_by": data.get("prepared_by", ""),
        "visitors": visitors,
        "deliveries": deliveries,
        "delays": delays,
        "workforce": workforce,
        "workforce_total_hours": workforce_total,
        "work_completed": work_completed,
        "safety": safety_ctx,
        "rfis": rfis,
        "issues": issues,
        "signed_by": data.get("signed_by", ""),
        "signed_date": data.get("signed_date", ""),
    }


# ── Post-Processing ──

def apply_alternating_shading(doc):
    """Apply alternating row shading to all tables in the document."""
    for table in doc.tables:
        for row_idx, row in enumerate(table.rows):
            if row_idx == 0:
                continue  # Skip header row
            body_idx = row_idx - 1
            if body_idx % 2 == 1:
                for cell in row.cells:
                    set_cell_shading(cell, LIGHT_GRAY_HEX)


def build_photo_grid(doc, photos, placeholder_paragraph):
    """Replace the placeholder paragraph with photo grid tables.

    If a photo has a 'file_path' and the file exists, the actual image is
    embedded. Otherwise a compact caption-only row is inserted (no gray
    placeholder boxes).
    """
    from docx.shared import Inches

    placeholder_element = placeholder_paragraph._p

    if not photos:
        placeholder_paragraph.clear()
        run = placeholder_paragraph.add_run("No photos attached.")
        run.font.name = "Calibri"
        run.font.size = Pt(9)
        run.font.color.rgb = FOOTER_GRAY
        run.font.italic = True
        return

    parent = placeholder_element.getparent()
    placeholder_index = list(parent).index(placeholder_element)
    parent.remove(placeholder_element)

    photos_per_row = 2
    num_rows = (len(photos) + photos_per_row - 1) // photos_per_row
    insert_idx = placeholder_index

    for row_idx in range(num_rows):
        photo_table = doc.add_table(rows=2, cols=photos_per_row)
        photo_table.alignment = WD_TABLE_ALIGNMENT.LEFT
        photo_table.autofit = False
        set_column_widths(photo_table, [8.5, 8.5])

        for col_idx in range(photos_per_row):
            photo_idx = row_idx * photos_per_row + col_idx

            image_cell = photo_table.rows[0].cells[col_idx]
            image_cell.text = ""
            p = image_cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER

            if photo_idx < len(photos):
                photo = photos[photo_idx]
                number = photo.get("number", photo_idx + 1)
                file_path = photo.get("file_path", "")

                # Try to embed actual image
                if file_path and Path(file_path).exists():
                    run = p.add_run()
                    run.add_picture(file_path, width=Inches(3.0))
                    set_cell_borders(image_cell)
                else:
                    # No image file - leave cell empty with border
                    set_cell_borders(image_cell)

                # Caption row
                caption_cell = photo_table.rows[1].cells[col_idx]
                caption_cell.text = ""
                cp = caption_cell.paragraphs[0]
                cp.alignment = WD_ALIGN_PARAGRAPH.CENTER

                num_run = cp.add_run(f"Photo {number}: ")
                num_run.font.name = "Calibri"
                num_run.font.size = Pt(9)
                num_run.font.bold = True
                num_run.font.color.rgb = DARK_TEXT

                desc_run = cp.add_run(photo.get("description", ""))
                desc_run.font.name = "Calibri"
                desc_run.font.size = Pt(9)
                desc_run.font.color.rgb = DARK_TEXT

                set_cell_borders(caption_cell)
            else:
                set_cell_borders(image_cell)
                set_cell_borders(photo_table.rows[1].cells[col_idx])

        tbl_element = photo_table._tbl
        parent.remove(tbl_element)
        parent.insert(insert_idx, tbl_element)
        insert_idx += 1

        if row_idx < num_rows - 1:
            spacer = parse_xml(
                f'<w:p {nsdecls("w")}>'
                f'  <w:pPr><w:spacing w:before="80" w:after="80"/></w:pPr>'
                f'</w:p>'
            )
            parent.insert(insert_idx, spacer)
            insert_idx += 1


def post_process(doc, photos):
    """Apply alternating shading and build photo grid."""
    # Find and replace photo placeholder
    for para in doc.paragraphs:
        if "__PHOTO_LOG_PLACEHOLDER__" in para.text:
            build_photo_grid(doc, photos, para)
            break

    apply_alternating_shading(doc)


# ── Main ──

def generate(data, output_path):
    """Render the template with data and post-process."""
    if not TEMPLATE_PATH.exists():
        print(f"Error: Template not found at {TEMPLATE_PATH}")
        print("Run 'python build_template.py' first to generate it.")
        sys.exit(1)

    context = prepare_context(data)
    photos = data.get("photos", [])

    tpl = DocxTemplate(str(TEMPLATE_PATH))
    tpl.render(context)
    tpl.save(output_path)

    # Post-process: open the rendered doc with python-docx for shading + photos
    from docx import Document
    doc = Document(output_path)
    post_process(doc, photos)
    doc.save(output_path)

    return output_path


def main():
    parser = argparse.ArgumentParser(description="Generate a Daily Site Diary (.docx)")
    parser.add_argument("--input", "-i", help="Path to JSON input file (reads stdin if omitted)")
    parser.add_argument("--output", "-o", required=True, help="Output .docx file path")
    args = parser.parse_args()

    if args.input:
        with open(args.input) as f:
            data = json.load(f)
    else:
        data = json.load(sys.stdin)

    output = generate(data, args.output)
    print(f"Generated: {output}")


if __name__ == "__main__":
    main()
