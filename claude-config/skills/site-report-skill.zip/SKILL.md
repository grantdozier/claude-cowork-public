---
name: site-report
description: Transform raw field notes or voice transcripts into professional, branded daily site diaries in Microsoft Word format. Handles rough bullet points, WhatsApp dumps, voice transcripts, and phone call transcripts. Classifies information into standard report sections, applies industry-standard writing conventions (PMBOK, FIDIC, NEC4), detects change order triggers and safety incidents, and outputs a branded .docx with all sections present. Use when a user provides field notes and needs a daily site report, site diary, daily diary, daily construction report, or daily log. Also trigger when the user says "write today's report", "format these notes into a report", "site diary from these notes", "daily report", or "here are my field notes".
---

# Daily Site Diary Skill

Transform raw field notes into a professional, branded daily site diary (.docx). One input, one output. No Q&A.

## Why This Matters

Daily site diaries are the single most important record a contractor produces. When a defect claim surfaces six months later, when a delay dispute goes to arbitration, when a regulator asks what happened on Tuesday the 14th, the daily diary is what gets pulled out.

Courts place more weight on a contemporaneous diary entry than on witness testimony months after the fact. FIDIC explicitly lists site diaries as qualifying contemporary records for claim substantiation. NEC4 requires robust daily record keeping as essential to recovering entitlement. A consistent, factual diary set is admissible evidence. An inconsistent, editorialized one may be excluded entirely.

The problem is that writing these reports is tedious. Foremen and PMs spend 45-90 minutes per day on them. Most hate it. Many skip it. When they do write them, they're inconsistent and incomplete. This skill eliminates the formatting burden. The field crew captures what happened in whatever format comes naturally. Rough notes, a voice transcript, a WhatsApp dump. The skill handles the rest.

---

## How This Skill Works

This is a **single-pass formatting skill**. The user provides raw field data. The skill classifies it into report sections, applies professional writing standards, and generates a branded Word document. It does not ask follow-up questions. It does not invent information. It formats what it's given.

**The only question the skill may ask is "which project?" if multiple projects are active and the input doesn't specify.**

---

## Input Formats

The skill accepts raw field data in any of these formats:

- **Rough notes / bullet points** - typed at end of day, shorthand, incomplete sentences
- **Voice transcript** - from Whisper, Otter, or any speech-to-text tool
- **Phone call transcript** - from a voice AI agent (e.g. Retell) or recorded call
- **WhatsApp dump** - copy-pasted from a project group chat (multiple senders, timestamps, mixed media references)
- **Any combination** of the above

The input will be messy. That's the point. The skill's job is to turn chaos into a professional record.

---

## Step 1: Parse and Classify

Read the entire raw input and slot every piece of information into the correct report section. Use these classification rules:

| Report Section | What Gets Classified Here | Signals |
|----------------|--------------------------|---------|
| **Weather & Conditions** | Temperature, precipitation, wind, visibility, ground conditions, weather impact on work | Temperature numbers, "rain", "snow", "wind", "muddy", "frozen ground", "clear", "overcast" |
| **Site Supervisor** | Name of the person supervising site that day | Names with role context: "foreman", "super", "site manager", "running the job" |
| **Visitors** | Anyone visiting site who isn't regular crew (clients, inspectors, engineers, council) | Names + "visited", "inspection", "walkthrough", "came to site", "council", "building inspector" |
| **Deliveries** | Materials received, supplier names, quantities, delivery dockets, rejected materials | "Delivered", "received", "dropped off", supplier names, quantities, "docket", "rejected" |
| **Delays** | Anything that held up work, stoppages, waiting time, weather delays, third-party delays | "Delayed", "couldn't", "waiting for", "held up", "stopped", "stood down", "no access" |
| **Workforce** | Crew names, trades, headcounts, start/finish times, hours worked, cost codes, subcontractor presence | Trade names, crew sizes, "3 chippies", "Smith Electric on site", time references, "started at 7" |
| **Work Completed** | What was done today: tasks, areas, quantities, scope references, progress | Action verbs: "completed", "installed", "poured", "erected", "pulled wire", area names, quantities |
| **Safety & Environmental** | Toolbox talks, incidents, near misses, safety observations, environmental notes | "Toolbox", "incident", "near miss", "safety", "spill", "hazard", "JSA", "SWMS" |
| **RFIs & Instructions** | RFIs submitted or received, architect/engineer instructions, design changes, ASIs | "RFI", "instruction", "architect said", "engineer confirmed", "ASI", "design change" |
| **Issues & Notes** | Anything else: general observations, tomorrow's plan, items requiring attention, coordination notes | Catch-all for information that doesn't fit above |

### Classification Principles

1. **One fact, one section.** If a statement contains information for multiple sections, split it. "Concrete delivered at 7:30 but the pump broke down" → Deliveries gets the concrete arrival, Delays gets the pump breakdown.

2. **Preserve the user's meaning.** Don't reinterpret. If the user says "the sparkies were slow today", that goes in Issues & Notes as a factual observation, not in Delays (unless specific delay time/impact is stated).

3. **Timestamps belong with their content.** "10am, inspector arrived" → the timestamp goes into the Visitors row, not stripped out.

4. **WhatsApp sender context.** In a WhatsApp dump, different senders may report on different areas. Use the sender context to attribute information but don't include sender names in the report unless they're identified as a crew member or visitor.

---

## Step 1b: Detect Project Type

Infer the project type from context in the raw input. Add `project_type` to the JSON output. Use `references/checklist.md` as the completeness lens for that type - it contains section-by-section checklists tuned to each project category.

| Type | Signals in Input |
|------|-----------------|
| **Commercial** | Office, retail, multi-story, tower crane, fire rating, lifts, BCA, fitout, tenancy, HVAC plant, curtain wall, core, podium |
| **Residential** | House, dwelling, unit, kitchen, bathroom, consent stages, weathertightness, cladding, insulation, gib stopping, carpet, landscaping |
| **Civil** | Road, pipe, earthworks, compaction, chainage, traffic management, culvert, kerb, pavement, stormwater, watermain, trench |
| **Industrial** | HVAC, mechanical plant, commissioning, shutdown, confined space, hot works, process piping, warehouse, cold store |

**Rules:**
- Default to `"commercial"` if the signals are ambiguous or mixed
- Use the project name as a strong hint ("Riverside Commercial Build" → commercial)
- Once detected, the project type informs which checklist sections to prioritize when reviewing completeness
- The project type is included in the JSON output but does not change the document structure or sections

---

## Step 2: Apply Voice and Style Rules

Transform the classified content from rough field language into professional report language. These rules are non-negotiable. They come from PMBOK, FIDIC, NEC4, CIOB, and construction law:

### Writing Rules

1. **Past tense** for all completed work. "Poured 25 m3 of 32 MPa concrete to Level 2 slab, Grid A-C."

2. **Third person** in the report body. "The crew installed..." or "Smith Electric completed..." Never "I" or "we."

3. **Factual and objective.** Zero opinions. Zero blame. Zero emotional language. "Subcontractor A did not commence work as scheduled." Not "Sub A failed to show up again."

4. **Specific and quantitative.** Locations, quantities, measurements, names, times. "Installed 200 LF of conduit on Level 2, east wing." Not "Did some electrical work." If the raw input is vague, reproduce it as-is. Do not inflate with invented specifics.

5. **Concise declarative sentences.** Short factual statements or structured entries. Not narratives, not stories, not commentary.

6. **Neutral on causation.** Describe what happened and the impact. Do not assign blame or speculate. "Concrete delivery arrived at 07:30 (scheduled 06:45). Approximately 45 minutes of productive pour time lost." Not "ABC Concrete was late because they don't care about schedules."

7. **No editorializing.** No exaggeration, no sarcasm, no frustration. A report that says "totally incompetent subcontractor" will undermine the credibility of the entire diary set if read in court.

### What NOT to Change

- **Don't upgrade vague input into specific claims.** If the user says "did some framing", write "Framing work performed". Don't invent "Completed 40% of Level 2 framing."
- **Don't add information that wasn't provided.** If weather isn't mentioned, the Weather section stays blank. Don't guess "Clear skies, 18C."
- **Don't merge separate items.** If the user mentions two different delays, they get two separate entries.

---

## Step 3: Analyse Attached Photos

Photos serve two purposes: they are **data sources** that feed information into the report sections, AND they appear in the **Photo Log** at the end of the document.

When the user attaches photos, analyse each one and determine:
1. Is this a **documentary photo** (site progress, work completed, conditions)? → Photo Log + may inform Work Completed, Equipment, or Weather sections
2. Is this a **record document** (sign-in sheet, tailgate form, delivery docket, inspection form)? → Extract the data and feed it into the relevant report sections. **Do NOT add record documents to the Photo Log.** They are data inputs, not documentary photos.

### Documentary Photos (Site Progress)

Standard construction photos: shots of work in progress, completed work, site conditions, equipment.

**Caption rules (keep captions SHORT - max 15 words):**
- Activity + location. That's it.
- Good: "Concrete pour in progress, Level 2 slab, Grid A-C"
- Good: "Wall framing complete, north elevation"
- Bad: "Concrete pour in progress via pump truck positioned at south access road. 32 MPa ready-mix placed to slab section, rebar reinforcement visible." (too long - save detail for the Work Completed section)
- Never speculate. If you can't identify something, describe what you see
- Use the project context from the user's notes to connect photos to activities

### Record Documents (Data Extraction)

Photos of paperwork that contain structured data:

| Photo Of | Extract Into |
|----------|-------------|
| **Crew sign-in sheet** | Workforce section: names, trades, start times, hours |
| **Tailgate / toolbox talk form** | Safety section: topic, attendees, date |
| **Delivery docket** | Deliveries section: supplier, material, quantity, docket number, time |
| **Inspection form / checklist** | RFIs & Instructions or Work Completed: inspection result, items noted |
| **Daily whiteboard / coordination board** | Issues & Notes or Work Completed: planned activities, assignments |

**Extraction rules:**
- Read every legible field on the document
- Cross-reference with the user's written notes. If the notes say "4 labourers" but the sign-in sheet shows 5 names, use the sign-in sheet (it's the primary record) and note the discrepancy
- If handwriting is unclear, note what you can read and flag what's illegible
- Extract data into the correct report sections as if the user had typed it
- **Do NOT add record document photos to the Photo Log.** Their data goes into the relevant sections. Only documentary site photos go in the Photo Log.

### Photo Log Output

In the Photo Log section of the report, list each documentary photo with its number and short caption. Reference which user-attached photo corresponds to each entry (e.g., "Photo 1 (first image attached)"). The user's photos are already visible in the conversation. Do NOT create placeholder boxes, gray boxes, or "insert image here" text.

---

## Step 4: Detect Flags

Scan the classified content for two critical categories. These are flagged **in the chat response** after delivering the document, not embedded in the report itself. The report stays clean and factual.

### Change Order Triggers

Flag if the input mentions any of:
- Unforeseen or differing site conditions ("hit rock", "found asbestos", "underground services not shown on drawings", "different soil than geotech report")
- Instructions from the client/architect/engineer that appear to differ from the original contract scope
- Delays caused by other parties (late access, late information, other trades blocking)
- Work not shown on drawings or specifications
- Conditions that differ from what was represented at tender

**Chat flag format:**
> **Potential Change Order Detected:** [Brief description of what was found in the notes]. This may warrant a formal notice under your contract's change provisions. Use the Change Order Management skill to draft a notice if needed.

### Safety Incidents

Flag if the input mentions any of:
- Any injury, however minor (first aid, medical treatment, lost time)
- Near misses
- Unsafe conditions observed but not yet rectified
- Equipment damage
- Environmental incidents (spills, contamination)

**Chat flag format:**
> **Safety Incident Noted:** [Brief description]. The diary entry records the facts. A separate formal incident report should be filed per your company's WHS/OHS requirements and any regulatory obligations.

---

## Step 5: Generate Output

Output the complete report as **structured markdown** in the chat. Use the exact sections, order, and table structure defined below. The user can copy this into their own Word template or use it directly.

- Use markdown tables for each section
- Include all sections even if empty (empty rows)
- Keep the report clean and factual - no commentary, no suggestions, no "here's your report" preamble

### Document Structure

The document always contains **every section**, in this order, regardless of whether data was provided. Sections with no data have empty table rows. No placeholder text, no "N/A", no messaging about missing information. Just blank rows the user can fill in when they open the document in Word.

**Header** (repeating every page):
- Left: "DAILY SITE DIARY" + project name
- Right: (empty)

**Project Information Block:**

| Field | Field |
|-------|-------|
| Project: | Report No: |
| Date: | Day: |
| Weather: | Temp: °C / °C |
| Site Supervisor: | Prepared By: |

**Section 1: Visitors**

| Time | Name | Organisation | Purpose |
|------|------|-------------|---------|

**Section 2: Deliveries**

| Time | Supplier | Material | Quantity | Docket # |
|------|----------|----------|----------|----------|

**Section 3: Delays**

| Description | Cause | Duration | Impact |
|-------------|-------|----------|--------|

**Section 4: Workforce**

| Crew / Trade | Start | Finish | Hours | Cost Code | Scope / Area |
|-------------|-------|--------|-------|-----------|-------------|
| **Total** | | | **-** | | |

**Section 5: Work Completed**

| Task / Activity | Quantity | Unit | Area / Location | Notes |
|----------------|----------|------|-----------------|-------|

**Section 6: Safety & Environmental**

| Item | Details |
|------|---------|
| Toolbox talk held | |
| Incidents / Near misses | |
| Safety observations | |
| Environmental notes | |

**Section 7: RFIs & Instructions**

| Ref # | Description | Direction | Status |
|-------|-------------|-----------|--------|

**Section 8: Issues & General Notes**

_(Free-form area)_

**Section 9: Photo Log**

| # | Description | Location / Area |
|---|-------------|-----------------|

List each documentary photo with its number, short caption, and location. Only include site photos here, not record documents (sign-in sheets, dockets, etc.).

**Sign-off:**

| Signed | Date |
|--------|------|

**Footer** (repeating): "Daily Site Diary" | Page X of Y

### Branding Specification

| Element | Specification |
|---------|--------------|
| Primary color | #1B3A4B (navy), section headers, header bar |
| Secondary color | #E8862A (orange), accents, alert borders |
| Body text | Calibri 11pt, #2D3436 |
| Section headers | Calibri Bold 13pt, #1B3A4B, uppercase |
| Table header rows | #1B3A4B background, white text, Calibri Bold 10pt |
| Table body rows | Alternating white / #F3F5F7 (light gray) |
| Table borders | #D5D8DC (light gray), thin |
| Header branding | None (generic, unbranded template) |

### Scripts (Advanced - Claude Code / Co-Work only)

This skill package includes Python scripts for generating branded .docx files. These are optional and only work in environments with code execution (Claude Code, co-work sessions). The scripts are:
- `build_template.py` - generates the editable Word template
- `generate_site_diary.py` - fills the template with JSON data
- `template.docx` - the pre-built template

These are not required. The skill works fully from SKILL.md alone.

---

## Edge Cases

### No-Work Day
Report still generated. Work Completed table has one row: "No work performed due to [reason from input]. Site secured." All other sections populated as normal from whatever information is in the input.

### Retrospective Report
If the date referenced in the notes is clearly not today, note in the Prepared By field: "Prepared [actual date] for works on [report date]." Courts and arbitrators distinguish between same-day and retrospective records. Transparency protects credibility.

### Conflicting Information
If the raw input contradicts itself (e.g., "no rain today" but also "stopped work because of the weather"), include both statements as-is in their respective sections. Flag the contradiction in the chat response so the user can reconcile before finalizing.

### Subcontractor-Only Day
Own forces rows in the Workforce table are empty. Subcontractor crews are documented as normal. The report is still required. The site was active.

### Incident on Site
Include the factual description in the Safety section. Flag in chat: a formal incident report should be filed separately per WHS/OHS requirements. The daily diary records what happened; it is not a substitute for a statutory incident report.

### Multi-Language Input
Common in construction (Spanish in US, French in Quebec, te reo Maori in NZ). Translate and standardize in the report body. If a term is significant (e.g., a local regulatory term), note the original.

### Continuation from Previous Day
If the user says "finished the pour from yesterday", include as-is: "Concrete pour continued from previous day. [Details from input]." Do not attempt to reference or load a previous report.

### Very Sparse Input
If the user provides only 2-3 sentences, format those into the appropriate sections and leave everything else blank. Do not pad the report. A short honest record is better than an inflated one.

---

## Key Principles

1. **Format, don't fabricate.** The skill organizes and presents what the user provides. If it's not in the input, the section stays blank. This is the most important rule.

2. **Reports are legal records.** Every word could be read by a lawyer, arbitrator, or judge years from now. The voice and style rules exist because courts have excluded editorialized, inconsistent, or retrospective records from evidence. Follow them without exception.

3. **All sections, always.** Every section appears in every report, even if empty. The user fills in blanks in Word before exporting to PDF. Consistent structure across every diary entry is what makes a record set admissible.

4. **Flag, don't bury.** Change order triggers and safety incidents are flagged in chat, not embedded in the document. They are too important to miss in a wall of text, and too sensitive to automate into a formal record without human review.

5. **The foreman's voice, the PM's standard.** Accept rough, spoken-word input. Produce professional, legally defensible output. The skill bridges the gap between how field crews talk and how PMs need to document. Never make the field crew feel like their input wasn't good enough.

6. **One pass, no interrogation.** Raw notes in, Word document out. No asking for clarification, no "can you tell me more about...", no conversation. The only question is "which project?" if it's ambiguous.

7. **Consistent every time.** Same sections, same order, same format, same branded template. Consistency is what makes a record set hold up as evidence. One report that looks different from the rest raises questions about the whole set.

8. **Human reviews, AI drafts.** The .docx is a draft. The PM opens it in Word, reviews every entry, fills in gaps, corrects anything that was misclassified, then exports to PDF. The AI never produces a final record, only a starting point.

---

## Integration with Other Skills

### Change Order Management
When the chat response flags a potential change order, the user can immediately use the Change Order Management skill to:
- Extract the relevant contract clause and notice requirements
- Draft a formal change order notice letter
- Begin the pricing and documentation workflow

The daily diary entry becomes the contemporaneous record that supports the change order claim.

### Contract Reviewer
If the user has reviewed their contract with the Contract Reviewer skill, the change provisions, notice periods, and markup allowances are already documented. The site diary flags reference these ("Consider issuing notice per your contract's change provisions"), prompting the user to check their contract review output.
