#!/usr/bin/env python3
"""
Build the Daily Site Diary template (.docx) with Jinja2 placeholders.

Run this once to generate template.docx. The template can then be edited
visually in Word to tweak fonts, colors, spacing, or column widths.
The Jinja2 tags ({{variable}}, {%tr for ...%}) survive Word editing
as long as they are not deleted.

Usage:
    python build_template.py
"""

from pathlib import Path

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import nsdecls
from docx.oxml import parse_xml

# ── Brand Colors (matched to ContractorOS logo) ──

NAVY = RGBColor(0x1B, 0x3A, 0x4B)
DARK_TEXT = RGBColor(0x2D, 0x34, 0x36)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
BORDER_GRAY = "D5D8DC"
NAVY_HEX = "1B3A4B"
LIGHT_GRAY_HEX = "F3F5F7"
FOOTER_GRAY = RGBColor(0x6B, 0x72, 0x80)

SCRIPT_DIR = Path(__file__).parent


# ── Helpers ──

def set_cell_shading(cell, color_hex):
    shading = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{color_hex}"/>')
    cell._tc.get_or_add_tcPr().append(shading)


def set_cell_borders(cell, color=BORDER_GRAY, size="4"):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = parse_xml(
        f'<w:tcBorders {nsdecls("w")}>'
        f'  <w:top w:val="single" w:sz="{size}" w:space="0" w:color="{color}"/>'
        f'  <w:left w:val="single" w:sz="{size}" w:space="0" w:color="{color}"/>'
        f'  <w:bottom w:val="single" w:sz="{size}" w:space="0" w:color="{color}"/>'
        f'  <w:right w:val="single" w:sz="{size}" w:space="0" w:color="{color}"/>'
        f'</w:tcBorders>'
    )
    tcPr.append(tcBorders)


def set_column_widths(table, widths_cm):
    for i, width in enumerate(widths_cm):
        if i < len(table.columns):
            table.columns[i].width = Cm(width)
            for row in table.rows:
                row.cells[i].width = Cm(width)


def style_header_cell(cell, text):
    cell.text = ""
    p = cell.paragraphs[0]
    run = p.add_run(text)
    run.font.name = "Calibri"
    run.font.size = Pt(9)
    run.font.bold = True
    run.font.color.rgb = WHITE
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    set_cell_shading(cell, NAVY_HEX)
    set_cell_borders(cell, NAVY_HEX)


def style_body_cell(cell, text, bold=False):
    cell.text = ""
    p = cell.paragraphs[0]
    run = p.add_run(text)
    run.font.name = "Calibri"
    run.font.size = Pt(9)
    run.font.color.rgb = DARK_TEXT
    if bold:
        run.font.bold = True
    set_cell_borders(cell)


def add_section_header(doc, title):
    p = doc.add_paragraph()
    p.space_before = Pt(14)
    p.space_after = Pt(4)
    run = p.add_run(title.upper())
    run.font.name = "Calibri"
    run.font.size = Pt(13)
    run.font.bold = True
    run.font.color.rgb = NAVY


def add_looped_table(doc, headers, jinja_vars, loop_var, loop_collection, col_widths):
    """Add a table with a Jinja2 row loop for docxtpl.

    docxtpl's {%tr} regex replaces the ENTIRE <w:tr> with the directive text.
    So we need 4 rows:
      Row 0: Header
      Row 1: {%tr for ...%} only (consumed entirely, becomes loop opener)
      Row 2: Data template row (no {%tr} tags, becomes loop body)
      Row 3: {%tr endfor %} only (consumed entirely, becomes loop closer)
    """
    table = doc.add_table(rows=4, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.autofit = False

    # Row 0: Header
    for i, header in enumerate(headers):
        style_header_cell(table.rows[0].cells[i], header)

    # Row 1: Loop opener (entire row consumed by docxtpl)
    table.rows[1].cells[0].paragraphs[0].text = f"{{%tr for {loop_var} in {loop_collection} %}}"

    # Row 2: Data template (becomes the loop body)
    for i, var in enumerate(jinja_vars):
        cell = table.rows[2].cells[i]
        cell.text = ""
        p = cell.paragraphs[0]
        run = p.add_run(f"{{{{{loop_var}.{var}}}}}")
        run.font.name = "Calibri"
        run.font.size = Pt(9)
        run.font.color.rgb = DARK_TEXT
        set_cell_borders(cell)

    # Row 3: Loop closer (entire row consumed by docxtpl)
    table.rows[3].cells[0].paragraphs[0].text = "{%tr endfor %}"

    set_column_widths(table, col_widths)
    return table


# ── Build Template ──

def build_template():
    doc = Document()

    # ── Page Setup ──
    section = doc.sections[0]
    section.page_width = Cm(21.0)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.0)
    section.bottom_margin = Cm(1.5)
    section.left_margin = Cm(2.0)
    section.right_margin = Cm(2.0)

    # ── Header ──
    header = section.header
    header.is_linked_to_previous = False
    p = header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT

    run = p.add_run("DAILY SITE DIARY")
    run.font.name = "Calibri"
    run.font.size = Pt(16)
    run.font.bold = True
    run.font.color.rgb = NAVY

    p.add_run("\n")
    run2 = p.add_run("{{project}}")
    run2.font.name = "Calibri"
    run2.font.size = Pt(10)
    run2.font.color.rgb = DARK_TEXT

    # Divider line
    p_divider = header.add_paragraph()
    p_divider.space_before = Pt(4)
    p_divider.space_after = Pt(0)
    pPr = p_divider._p.get_or_add_pPr()
    pBdr = parse_xml(
        f'<w:pBdr {nsdecls("w")}>'
        f'  <w:bottom w:val="single" w:sz="8" w:space="1" w:color="{NAVY_HEX}"/>'
        f'</w:pBdr>'
    )
    pPr.append(pBdr)

    # ── Footer ──
    footer = section.footer
    footer.is_linked_to_previous = False
    footer_table = footer.add_table(rows=1, cols=2, width=Cm(17.0))

    left_cell = footer_table.rows[0].cells[0]
    left_cell.text = ""
    run = left_cell.paragraphs[0].add_run("Daily Site Diary")
    run.font.name = "Calibri"
    run.font.size = Pt(8)
    run.font.color.rgb = FOOTER_GRAY

    right_cell = footer_table.rows[0].cells[1]
    right_cell.text = ""
    p = right_cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = p.add_run("Page ")
    run.font.name = "Calibri"
    run.font.size = Pt(8)
    run.font.color.rgb = FOOTER_GRAY
    fld_begin = parse_xml(f'<w:fldChar {nsdecls("w")} w:fldCharType="begin"/>')
    run._r.append(fld_begin)
    instr = parse_xml(f'<w:instrText {nsdecls("w")} xml:space="preserve"> PAGE </w:instrText>')
    run._r.append(instr)
    fld_end = parse_xml(f'<w:fldChar {nsdecls("w")} w:fldCharType="end"/>')
    run._r.append(fld_end)

    run2 = p.add_run(" of ")
    run2.font.name = "Calibri"
    run2.font.size = Pt(8)
    run2.font.color.rgb = FOOTER_GRAY
    fld_begin2 = parse_xml(f'<w:fldChar {nsdecls("w")} w:fldCharType="begin"/>')
    run2._r.append(fld_begin2)
    instr2 = parse_xml(f'<w:instrText {nsdecls("w")} xml:space="preserve"> NUMPAGES </w:instrText>')
    run2._r.append(instr2)
    fld_end2 = parse_xml(f'<w:fldChar {nsdecls("w")} w:fldCharType="end"/>')
    run2._r.append(fld_end2)

    # ── Project Info Block ──
    info_table = doc.add_table(rows=4, cols=4)
    info_table.alignment = WD_TABLE_ALIGNMENT.LEFT
    info_table.autofit = False
    set_column_widths(info_table, [3.0, 5.5, 3.0, 5.5])

    info_fields = [
        ("Project:", "{{project}}", "Report No:", "{{report_no}}"),
        ("Date:", "{{date}}", "Day:", "{{day}}"),
        ("Weather:", "{{weather}}", "Temp:", "{{temp_display}}"),
        ("Site Supervisor:", "{{site_supervisor}}", "Prepared By:", "{{prepared_by}}"),
    ]

    for row_idx, (label1, val1, label2, val2) in enumerate(info_fields):
        cells = info_table.rows[row_idx].cells
        for ci, (text, is_label) in enumerate([(label1, True), (val1, False), (label2, True), (val2, False)]):
            cells[ci].text = ""
            run = cells[ci].paragraphs[0].add_run(text)
            run.font.name = "Calibri"
            run.font.size = Pt(10)
            run.font.color.rgb = NAVY if is_label else DARK_TEXT
            if is_label:
                run.font.bold = True
            set_cell_borders(cells[ci])

    # ── Visitors ──
    add_section_header(doc, "Visitors")
    add_looped_table(doc,
        headers=["Time", "Name", "Organisation", "Purpose"],
        jinja_vars=["time", "name", "organisation", "purpose"],
        loop_var="v", loop_collection="visitors",
        col_widths=[2.0, 4.0, 4.0, 7.0])

    # ── Deliveries ──
    add_section_header(doc, "Deliveries")
    add_looped_table(doc,
        headers=["Time", "Supplier", "Material", "Quantity", "Docket #"],
        jinja_vars=["time", "supplier", "material", "quantity", "docket"],
        loop_var="d", loop_collection="deliveries",
        col_widths=[2.0, 3.5, 5.0, 3.0, 3.5])

    # ── Delays ──
    add_section_header(doc, "Delays")
    add_looped_table(doc,
        headers=["Description", "Cause", "Duration", "Impact"],
        jinja_vars=["description", "cause", "duration", "impact"],
        loop_var="dl", loop_collection="delays",
        col_widths=[5.5, 4.5, 2.0, 5.0])

    # ── Workforce ──
    # Workforce needs a loop + a static totals row, so we build manually
    add_section_header(doc, "Workforce")
    wf_headers = ["Crew / Trade", "Start", "Finish", "Hours", "Cost Code", "Scope / Area"]
    wf_vars = ["crew_trade", "start", "finish", "hours", "cost_code", "scope_area"]

    # 1 header + 1 for-opener + 1 data row + 1 endfor + 1 totals = 5 rows
    wf_table = doc.add_table(rows=5, cols=6)
    wf_table.alignment = WD_TABLE_ALIGNMENT.LEFT
    wf_table.autofit = False

    for i, h in enumerate(wf_headers):
        style_header_cell(wf_table.rows[0].cells[i], h)

    # Row 1: Loop opener
    wf_table.rows[1].cells[0].paragraphs[0].text = "{%tr for w in workforce %}"

    # Row 2: Data template
    for i, var in enumerate(wf_vars):
        cell = wf_table.rows[2].cells[i]
        cell.text = ""
        p = cell.paragraphs[0]
        run = p.add_run(f"{{{{w.{var}}}}}")
        run.font.name = "Calibri"
        run.font.size = Pt(9)
        run.font.color.rgb = DARK_TEXT
        set_cell_borders(cell)

    # Row 3: Loop closer
    wf_table.rows[3].cells[0].paragraphs[0].text = "{%tr endfor %}"

    # Row 4: Totals row (static, always present)
    totals_data = ["Total", "", "", "{{workforce_total_hours}}", "", ""]
    for i, val in enumerate(totals_data):
        cell = wf_table.rows[4].cells[i]
        cell.text = ""
        p = cell.paragraphs[0]
        run = p.add_run(val)
        run.font.name = "Calibri"
        run.font.size = Pt(9)
        run.font.bold = True
        run.font.color.rgb = DARK_TEXT
        set_cell_borders(cell)

    set_column_widths(wf_table, [4.5, 1.8, 1.8, 1.5, 2.4, 5.0])

    # ── Work Completed ──
    add_section_header(doc, "Work Completed")
    add_looped_table(doc,
        headers=["Task / Activity", "Quantity", "Unit", "Area / Location", "Notes"],
        jinja_vars=["task", "quantity", "unit", "area", "notes"],
        loop_var="wc", loop_collection="work_completed",
        col_widths=[5.0, 2.0, 1.5, 4.0, 4.5])

    # ── Safety & Environmental ──
    # Fixed 4 rows, no loop needed
    add_section_header(doc, "Safety & Environmental")
    safety_table = doc.add_table(rows=5, cols=2)
    safety_table.alignment = WD_TABLE_ALIGNMENT.LEFT
    safety_table.autofit = False
    set_column_widths(safety_table, [4.0, 13.0])

    style_header_cell(safety_table.rows[0].cells[0], "Item")
    style_header_cell(safety_table.rows[0].cells[1], "Details")

    safety_items = [
        ("Toolbox talk held", "{{safety.toolbox_talk}}"),
        ("Incidents / Near misses", "{{safety.incidents}}"),
        ("Safety observations", "{{safety.observations}}"),
        ("Environmental notes", "{{safety.environmental}}"),
    ]
    for row_idx, (label, var) in enumerate(safety_items):
        style_body_cell(safety_table.rows[row_idx + 1].cells[0], label, bold=True)
        style_body_cell(safety_table.rows[row_idx + 1].cells[1], var)

    # ── RFIs & Instructions ──
    add_section_header(doc, "RFIs & Instructions")
    add_looped_table(doc,
        headers=["Ref #", "Description", "Direction", "Status"],
        jinja_vars=["ref", "description", "direction", "status"],
        loop_var="r", loop_collection="rfis",
        col_widths=[2.0, 7.0, 4.0, 4.0])

    # ── Issues & General Notes ──
    add_section_header(doc, "Issues & General Notes")
    issues_table = doc.add_table(rows=4, cols=2)
    issues_table.alignment = WD_TABLE_ALIGNMENT.LEFT
    issues_table.autofit = False
    set_column_widths(issues_table, [1.5, 15.5])

    # Row 0: Header
    style_header_cell(issues_table.rows[0].cells[0], "#")
    style_header_cell(issues_table.rows[0].cells[1], "Description")

    # Row 1: Loop opener
    issues_table.rows[1].cells[0].paragraphs[0].text = "{%tr for note in issues %}"

    # Row 2: Data template
    num_cell = issues_table.rows[2].cells[0]
    num_cell.text = ""
    run = num_cell.paragraphs[0].add_run("{{note.num}}")
    run.font.name = "Calibri"
    run.font.size = Pt(9)
    run.font.color.rgb = DARK_TEXT
    set_cell_borders(num_cell)

    desc_cell = issues_table.rows[2].cells[1]
    desc_cell.text = ""
    run = desc_cell.paragraphs[0].add_run("{{note.text}}")
    run.font.name = "Calibri"
    run.font.size = Pt(9)
    run.font.color.rgb = DARK_TEXT
    set_cell_borders(desc_cell)

    # Row 3: Loop closer
    issues_table.rows[3].cells[0].paragraphs[0].text = "{%tr endfor %}"

    # ── Photo Log ──
    add_section_header(doc, "Photo Log")
    p = doc.add_paragraph()
    run = p.add_run("__PHOTO_LOG_PLACEHOLDER__")
    run.font.name = "Calibri"
    run.font.size = Pt(9)
    run.font.color.rgb = DARK_TEXT

    # ── Sign-Off ──
    add_section_header(doc, "Sign-Off")
    signoff_table = doc.add_table(rows=2, cols=2)
    signoff_table.alignment = WD_TABLE_ALIGNMENT.LEFT
    style_header_cell(signoff_table.rows[0].cells[0], "Signed")
    style_header_cell(signoff_table.rows[0].cells[1], "Date")
    style_body_cell(signoff_table.rows[1].cells[0], "{{signed_by}}")
    style_body_cell(signoff_table.rows[1].cells[1], "{{signed_date}}")
    signoff_table.rows[1].height = Cm(1.5)

    # ── Save ──
    output_path = SCRIPT_DIR / "template.docx"
    doc.save(str(output_path))
    print(f"Template generated: {output_path}")
    return output_path


if __name__ == "__main__":
    build_template()
