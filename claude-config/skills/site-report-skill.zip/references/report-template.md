# Daily Site Diary: Report Template

This defines every section of the report, in order. All sections appear in every report.

---

## Project Information Block

| Field | Field |
|-------|-------|
| **Project:** | **Report No:** |
| **Date:** | **Day:** |
| **Weather:** | **Temp:** °C / °C |
| **Site Supervisor:** | **Prepared By:** |

---

## Section 1: Visitors

| Time | Name | Organisation | Purpose |
|------|------|-------------|---------|

Records anyone visiting site who is not regular crew. Clients, inspectors, engineers, council, consultants, subcontractor managers checking in.

---

## Section 2: Deliveries

| Time | Supplier | Material | Quantity | Docket # |
|------|----------|----------|----------|----------|

Records all materials received on site. Include supplier name, material description, quantity with units, and delivery docket reference. Also record rejected deliveries with reason.

---

## Section 3: Delays

| Description | Cause | Duration | Impact |
|-------------|-------|----------|--------|

Records any disruption that held up work. Document the cause objectively, the duration (start/end time or total time lost), and the impact on work or schedule. Do not assign blame. State facts.

---

## Section 4: Workforce

| Crew / Trade | Start | Finish | Hours | Cost Code | Scope / Area |
|-------------|-------|--------|-------|-----------|-------------|
| | | | | | |
| **Total** | | | **-** | | |

Records all personnel on site, own forces and subcontractors. Each trade/crew gets its own row. Include start and finish times, total hours, cost code if applicable, and what scope/area they were working in.

The Total row sums hours across all crews.

---

## Section 5: Work Completed

| Task / Activity | Quantity | Unit | Area / Location | Notes |
|----------------|----------|------|-----------------|-------|

The core of the report. Records what was actually done today. Each entry should be:
- **Specific:** What task, where, how much
- **Quantified:** Numbers, measurements, counts
- **Located:** Which area, level, gridline, zone

---

## Section 6: Safety & Environmental

| Item | Details |
|------|---------|
| Toolbox talk held | |
| Incidents / Near misses | |
| Safety observations | |
| Environmental notes | |

Records all safety-related activity. Toolbox talk topic, any incidents or near misses (factual description only), safety observations (positive or negative), and environmental notes (spills, dust, noise, erosion control).

---

## Section 7: RFIs & Instructions

| Ref # | Description | Direction | Status |
|-------|-------------|-----------|--------|

Records any RFIs submitted, responses received, architect/engineer instructions (ASIs), or design changes communicated on site. Direction = "Submitted to [party]" or "Received from [party]".

---

## Section 8: Issues & General Notes

Free-form section for:
- Items not captured in other sections
- Tomorrow's planned work
- Coordination notes
- Items requiring attention from others
- General observations

---

## Sign-Off

| Signed | Date |
|--------|------|

Space for the site supervisor or PM to sign the report after review.
