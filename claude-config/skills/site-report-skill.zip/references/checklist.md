# Completeness Checklist by Project Type

Use this to assess whether a daily report covers the minimum expected content for the project type. Not all items apply every day, but they should be consciously addressed (even if the answer is "none" or "not applicable today").

---

## All Project Types (Universal)

These items should appear in every daily report regardless of project type:

| Item | Critical? | Notes |
|------|-----------|-------|
| Date and day | Yes | Every report must be dated |
| Weather conditions | Yes | Temperature, precipitation, wind. Courts expect this. |
| Site supervisor name | Yes | Who was in charge today |
| Workforce on site | Yes | Trades, headcounts, hours |
| Work completed | Yes | What was done, where, how much |
| Safety section | Yes | Even if "no incidents", record that safety was considered |
| Delays (if any) | Yes | Every delay documented with cause, duration, impact |

---

## Commercial / Office Build

| Item | Expected Frequency | Notes |
|------|-------------------|-------|
| Subcontractor presence and crew counts | Daily | Multiple trades overlap on commercial builds |
| Equipment (crane, hoist, pump) | Daily | Tower cranes, hoists, concrete pumps |
| Concrete pours (volume, grade, location) | When occurring | Critical for structural records |
| Inspections (building consent, engineer) | When occurring | Pre-line, post-pour, fire stopping |
| RFIs and architect instructions | When occurring | High volume on commercial projects |
| Coordination issues between trades | As needed | Common on multi-trade floors |
| Fire stopping and penetration sealing | When occurring | Compliance-critical |
| Lift/escalator installation milestones | When occurring | Long-lead items |

---

## Residential (House Build / Multi-Unit)

| Item | Expected Frequency | Notes |
|------|-------------------|-------|
| Stage completion for consent inspections | At milestones | Foundation, framing, pre-line, pre-clad, final |
| Material deliveries (timber, trusses, windows) | When occurring | Track against order schedule |
| Owner/client site visits | When occurring | Record what was discussed |
| Subcontractor scheduling coordination | Daily | Tight sequencing on residential |
| Weathertightness observations | When relevant | Wrap, flashings, membrane |
| Appliance and fixture installations | When occurring | Kitchen, bathroom, laundry |

---

## Civil / Infrastructure

| Item | Expected Frequency | Notes |
|------|-------------------|-------|
| Equipment hours (detailed) | Daily | Civil is equipment-intensive |
| Earthworks quantities (cut/fill volumes) | Daily | m³ moved, compaction test results |
| Survey / set-out activities | When occurring | Alignment, levels, offsets |
| Compaction test results | When tested | DCP, nuclear density, Clegg hammer |
| Pipe laying (lengths, sizes, material) | Daily when occurring | Chainage references |
| Concrete pours (structures, headwalls) | When occurring | Volume, grade, slump, test cylinders |
| Environmental compliance | Daily | Erosion control, sediment, dust, water |
| Traffic management | Daily | Lane closures, traffic control in place |
| Utility locates and potholing | When occurring | Compare to as-built drawings |
| Unforeseen ground conditions | When encountered | Critical for variation claims |

---

## Industrial / Fit-Out

| Item | Expected Frequency | Notes |
|------|-------------------|-------|
| Mechanical equipment installation | When occurring | HVAC, process equipment, ductwork |
| Electrical switchboard and distribution | When occurring | Panel installation, cable pulling |
| Commissioning activities | When occurring | Testing, balancing, energisation |
| Hot works permits | When issued | Welding, cutting, grinding |
| Confined space entries | When occurring | Compliance-critical |
| Shutdowns / tie-ins to live systems | When occurring | High-risk, document thoroughly |
| Client operational constraints | Daily | Working around live operations |

---

## How to Use This Checklist

1. After classifying the raw input, scan this checklist for the project type
2. Items marked "Critical" that are missing from the input = blank sections in the report (not flagged, just blank)
3. Items that are "When occurring" only matter if the activity happened that day
4. The checklist is a reference for the AI to understand what a complete report looks like for each context. It is NOT presented to the user
