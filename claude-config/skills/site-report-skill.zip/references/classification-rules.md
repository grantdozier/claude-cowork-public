# Classification Rules: Raw Input to Report Sections

Rules for slotting raw field data into the correct report section.

---

## Primary Signals

Each keyword/pattern maps to a section. When a statement contains signals for multiple sections, split it.

### Weather & Conditions
**Trigger words:** rain, snow, wind, frost, ice, overcast, clear, sunny, fine, fog, hail, temperature, degrees, °C, °F, muddy, frozen, wet, dry, dust, ground conditions, humidity
**Also:** Any mention of weather impact on work ("stood down due to rain", "too wet to pour")

### Site Supervisor
**Trigger words:** supervisor, foreman, super, site manager, running the site, in charge today
**Note:** Usually appears as a name + role. If only a name is given with no role context, classify based on surrounding information.

### Visitors
**Trigger words:** visited, inspection, inspector, walkthrough, came to site, site visit, client visit, council, building inspector, engineer visited, architect on site
**Rule:** Anyone on site who is NOT regular crew or a subcontractor working. Head office staff visiting count as visitors.

### Deliveries
**Trigger words:** delivered, delivery, received, dropped off, arrived, docket, supplier, truck, shipment, load, unloaded, rejected, materials arrived, order received
**Also:** Supplier company names followed by material descriptions

### Delays
**Trigger words:** delayed, delay, couldn't, waiting for, held up, stopped, stood down, no access, held off, suspended, postponed, unable to, blocked, breakdown, outage, failed
**Rule:** Only classify as a delay if there was an actual stoppage or loss of productive time. "Running a bit behind" is an observation (Issues & Notes). "Stopped work for 2 hours" is a delay.

### Workforce
**Trigger words:** crew, workers, guys, labourers, chippies, sparkies, plumbers, fitters, welders, concreters, scaffolders, painters, started at, finished at, hours, headcount, on site today, [trade name], [company name] + number of workers
**Rule:** Any mention of who was on site and what trade they represent. Include subcontractor company names.

### Work Completed
**Trigger words:** completed, installed, poured, erected, pulled, stripped, laid, fixed, hung, fitted, connected, tested, commissioned, excavated, backfilled, compacted, built, framed, sheeted, lined, plastered, painted, welded, bolted
**Also:** References to specific areas/locations + activities ("Level 1 framing", "Grid C-D excavation")
**Rule:** This captures WHAT was done. WHO did it goes in Workforce.

### Safety & Environmental
**Trigger words:** toolbox, toolbox talk, JSA, SWMS, incident, near miss, injury, first aid, safety, hazard, PPE, fire, spill, environmental, dust, noise, erosion, sediment, safety observation
**Rule:** ALL safety content goes here, even positive observations ("housekeeping good").

### RFIs & Instructions
**Trigger words:** RFI, ASI, instruction, directed, architect said, engineer confirmed, design change, drawing revision, clarification, response received, submitted to
**Rule:** Formal communications about design/scope. Informal "the architect mentioned..." goes in Issues & Notes unless it's a directive.

### Issues & General Notes
**Trigger words:** tomorrow, next week, plan, coordination, meeting, note, general, other, FYI, heads up, reminder, follow up
**Rule:** Catch-all. Anything that doesn't clearly belong in another section. Also: tomorrow's planned work, coordination notes, observations that aren't delays or safety items.

---

## Split Rules

When one statement belongs in multiple sections:

| Raw Input | Split Into |
|-----------|-----------|
| "Concrete delivered at 7:30 but the pump broke down for an hour" | **Deliveries:** Concrete received at 07:30. **Delays:** Concrete pump breakdown, 1 hour lost. |
| "Smith Electric (3 sparkies) pulled wire on Level 2, started 7am finished 3:30pm" | **Workforce:** Smith Electric, 3 electricians, 07:00–15:30. **Work Completed:** Electrical wire pulled, Level 2. |
| "Inspector came at 10, passed the framing inspection on Level 1" | **Visitors:** Inspector, 10:00, framing inspection. **Work Completed:** Framing inspection passed, Level 1. |
| "Stood down at 2pm due to high winds, crane ops suspended" | **Delays:** High winds, crane operations suspended from 14:00. **Weather:** High winds from 14:00. |
| "Near miss with falling plywood, secured all loose materials" | **Safety:** Near miss, unsecured plywood. Corrective action: loose materials secured. |

---

## WhatsApp-Specific Rules

When classifying from a WhatsApp group chat dump:

1. **Timestamps in messages** map to the Time field in relevant sections
2. **Sender names** help attribute information but don't appear in the report (unless the sender is identified as a crew member or visitor)
3. **Photos referenced** in messages → note in Work Completed or relevant section: "Photo: [description]"
4. **Voice note transcripts** within the chat → classify the content like any other text
5. **Multiple senders reporting on the same event** → consolidate into one entry using the most detailed account
6. **Casual chat / jokes / off-topic** → ignore entirely, do not classify

---

## Voice Transcript-Specific Rules

1. **Filler words** ("um", "uh", "like", "you know") → strip out
2. **Repeated information** (speaker circles back to the same point) → consolidate into one entry
3. **Timestamps spoken** ("around 10 o'clock", "this morning", "after lunch") → convert to approximate times
4. **Names spoken casually** ("Dave's guys", "the plumber bloke") → use as-is if no formal name available
5. **Corrections mid-speech** ("no wait, it was 8 cubic, not 6") → use the corrected figure
