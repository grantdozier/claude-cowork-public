# Section Guide: What Belongs Where

Real examples showing how to classify and write entries for each section.

---

## Weather & Conditions

**What goes here:** Temperature (high/low), precipitation, wind, visibility, ground conditions, and impact on work.

**Good entries:**
- "Fine, 22°C / 14°C, light NW breeze. No impact on work."
- "Rain from 06:00 to 11:30. 12mm recorded. Ground soft in excavation areas, tracked out onto public road. Water cart deployed for dust suppression after rain cleared."
- "Overcast, 8°C / 2°C. Heavy frost overnight. Concrete curing blankets checked at 06:15, adequate."
- "High winds from 14:00 (gusts >40 km/h). Crane operations suspended at 14:20 per lift plan wind limits. Resumed 16:00."

**Bad entries:**
- "Nice day" (not specific enough)
- "Terrible weather, couldn't do anything" (editorialized and vague)

---

## Site Supervisor

**What goes here:** Name of the person supervising site that day.

**Good entries:**
- "Mark Thompson (Site Manager)"
- "Dave Wilson (Acting - Mark Thompson on leave)"

---

## Visitors

**What goes here:** Non-regular personnel visiting site. Clients, inspectors, consultants, council, head office.

**Good entries:**

| Time | Name | Organisation | Purpose |
|------|------|-------------|---------|
| 10:30 | Sarah Chen | ABC Architecture | Level 1 progress walkthrough |
| 14:00 | Building Inspector | Auckland Council | Pre-line inspection - framing, Level 1 east wing |
| 09:00 | Paul Roberts | Client (Riverside Properties) | Monthly progress review |

**Bad entries:**
- "Architect came by" (no name, no time, no purpose)
- "Some council guy was snooping around" (editorialized)

---

## Deliveries

**What goes here:** All materials received on site. Include rejected deliveries.

**Good entries:**

| Time | Supplier | Material | Quantity | Docket # |
|------|----------|----------|----------|----------|
| 07:30 | ReadyMix NZ | 32 MPa concrete | 8 m³ | D-4521 |
| 10:15 | PlaceMakers | 90x45 MSG8 framing timber | 2.4 m³ (1 truck) | PO-2234 |
| 13:00 | Steel & Tube | HD12 rebar | 2.5 tonne | ST-8891 |
| 08:00 | ABC Roofing Supply | Colorsteel Endura roofing | 120 m² | REJECTED - wrong profile (corrugate ordered, tray received) |

**Bad entries:**
- "Got some timber" (no supplier, no quantity, no docket)
- "Concrete showed up late as usual" (editorialized)

---

## Delays

**What goes here:** Anything that stopped or slowed work. Document cause, duration, and impact factually.

**Good entries:**

| Description | Cause | Duration | Impact |
|-------------|-------|----------|--------|
| Concrete delivery arrived 45 min late (scheduled 06:45, arrived 07:30) | Supplier dispatch error (confirmed by driver) | 45 min | Lost productive pour time. Pump repositioned. |
| No access to Level 3 east wing | Scaffold not completed by Access Co. | Full day | Framing crew redeployed to Level 2 west wing. |
| Power outage, site-wide | Grid supply failure (not site-related) | 2.5 hours (10:15-12:45) | All power tools down. Manual work continued where possible. |

**Bad entries:**
- "Delayed by concrete company" (no time, no duration, no impact)
- "Sub A was late again and held everyone up" (blame-assigning, not factual)
- "Weather delay" (which weather? How long? What was the impact?)

---

## Workforce

**What goes here:** Every person/crew on site. Own forces and subcontractors.

**Good entries:**

| Crew / Trade | Start | Finish | Hours | Cost Code | Scope / Area |
|-------------|-------|--------|-------|-----------|-------------|
| Own forces - Labourers (4) | 06:30 | 15:00 | 34 | SC-101 | Level 1 framing |
| Smith Electric (3 electricians) | 07:00 | 15:30 | 25.5 | - | Level 2 rough-in |
| Pacific Plumbing (3 plumbers) | 07:00 | 14:00 | 21 | - | Ground floor fitout |
| ProScaff (2 scaffolders) | 07:00 | 12:00 | 10 | - | Level 3 scaffold erection |
| **Total** | | | **90.5** | | |

**Bad entries:**
- "Crew on site" (who? How many? Which trade?)
- "The electricians" (no company name, no count, no hours)

---

## Work Completed

**What goes here:** What was actually done today. This is the most important section.

**Good entries:**

| Task / Activity | Quantity | Unit | Area / Location | Notes |
|----------------|----------|------|-----------------|-------|
| Wall framing completed, gridlines A-C north elevation | 40 | LM | Level 1 | Progress now ~70% (was 55% Friday) |
| Window headers installed W-101 through W-104 | 4 | EA | Level 1 | |
| Electrical rough-in: wire pulled circuits 1-12, panel LP-2A | 12 | circuits | Level 2 east wing | Smith Electric |
| Concrete poured to ground beam GB-3 | 4.5 | m³ | Grid D, south | 32 MPa, slump tested at 80mm |
| Formwork stripped from column C-4 | 1 | EA | Level 1 | 7-day strength test results pending |

**Bad entries:**
- "Did some framing" (where? How much?)
- "Good progress today" (meaningless without specifics)
- "Worked on the building" (this is not a report entry)

---

## Safety & Environmental

**What goes here:** All safety-related activity. Even if nothing happened, record that.

**Good entries:**

| Item | Details |
|------|---------|
| Toolbox talk held | Yes. Working at heights: ladder safety. 12 attendees. |
| Incidents / Near misses | Near miss: unsecured sheet of plywood blown from Level 2 scaffold platform at ~14:30 during wind gust. No injuries. Area below was cordoned. Immediate corrective action: all loose materials secured, additional tie-downs installed. |
| Safety observations | Housekeeping good across all levels. Scaffold tags checked, all current. |
| Environmental notes | Dust suppression active on haul road. Sediment control intact after overnight rain. |

**Bad entries:**
- "No safety issues" (record what you observed, not just the absence of problems)
- "Someone nearly got hurt" (who? What happened? What was done about it?)

---

## RFIs & Instructions

**What goes here:** RFIs submitted/received, architect instructions, engineer directives, design changes.

**Good entries:**

| Ref # | Description | Direction | Status |
|-------|-------------|-----------|--------|
| RFI-024 | Ceiling height clarification at corridor intersection Grid B/3 | Submitted to architect | Open - 1st day |
| RFI-023 | Level 2 partition layout zone C, dimension conflict | Submitted to architect | Open - 3rd day, blocking work |
| ASI-007 | Revised door hardware schedule (D-101 to D-108) | Received from architect | Acknowledged, procurement notified |

---

## Issues & General Notes

**What goes here:** Everything else. Tomorrow's plan. Coordination items. Observations.

**Good entries:**
- "RFI-023 response still pending, 3rd day waiting. Cannot proceed with Level 2 partition layout in zone C until resolved."
- "Tomorrow: Continue Level 1 framing south elevation. Concrete pour scheduled Thursday (12 m³, Level 1 slab section B)."
- "Coordination meeting with mechanical subcontractor scheduled Wednesday re: duct routing conflict at Level 2 corridor."
- "Client requested additional power outlet in reception area. Not in scope. Potential change order."
