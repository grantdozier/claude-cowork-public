#!/usr/bin/env python3
"""
Vector Data Extraction for Construction Drawings

Extracts text objects, construction tags, dimensions, scale information,
and geometric data from PDF drawing pages using PyMuPDF.

Each extracted item includes x,y coordinates for downstream annotation/visualisation.

Usage:
    python extract.py drawing.pdf -o extracted.json --pretty
    python extract.py drawing.pdf --page 1 -o page1.json
"""

import sys
import json
import re
import argparse
from pathlib import Path
from collections import defaultdict

try:
    import fitz  # PyMuPDF
except ImportError:
    print("ERROR: PyMuPDF required. Install with: pip install pymupdf --break-system-packages", file=sys.stderr)
    sys.exit(1)


# ── Tag patterns for Australian/international construction drawings ──

TAG_PATTERNS = {
    # Electrical
    r'\bL(\d{1,3})\b': {'category': 'electrical', 'description': 'Light fitting'},
    r'\bLD\b': {'category': 'electrical', 'description': 'LED downlight'},
    r'\bGPO\b': {'category': 'electrical', 'description': 'General power outlet'},
    r'\bDB\b': {'category': 'electrical', 'description': 'Distribution board'},
    r'\bSW\b': {'category': 'electrical', 'description': 'Switch'},
    r'\bEX\b': {'category': 'electrical', 'description': 'Exit light'},
    r'\bEM\b': {'category': 'electrical', 'description': 'Emergency light'},
    r'\bSD\b': {'category': 'electrical', 'description': 'Smoke detector'},
    r'\bFAN\b': {'category': 'electrical', 'description': 'Fan'},
    r'\bEF\b': {'category': 'electrical', 'description': 'Exhaust fan'},
    r'\bSPK\b': {'category': 'electrical', 'description': 'Speaker'},
    r'\bCAM\b': {'category': 'electrical', 'description': 'Camera'},
    r'\bSEN\b': {'category': 'electrical', 'description': 'Sensor'},
    # Plumbing
    r'\bWC\b': {'category': 'plumbing', 'description': 'Toilet'},
    r'\bWHB\b': {'category': 'plumbing', 'description': 'Wall hung basin'},
    r'\bSHR\b': {'category': 'plumbing', 'description': 'Shower'},
    r'\bSK\b': {'category': 'plumbing', 'description': 'Sink'},
    r'\bFL\b': {'category': 'plumbing', 'description': 'Floor drain'},
    r'\bFD\b': {'category': 'plumbing', 'description': 'Floor drain'},
    r'\bHW\b': {'category': 'plumbing', 'description': 'Hot water unit'},
    r'\bTAP\b': {'category': 'plumbing', 'description': 'Tap/faucet'},
    r'\bDF\b': {'category': 'plumbing', 'description': 'Drinking fountain'},
    r'\bCWT\b': {'category': 'plumbing', 'description': 'Cistern/water tank'},
    # Fire
    r'\bFH\b': {'category': 'fire', 'description': 'Fire hose reel'},
    r'\bFHR\b': {'category': 'fire', 'description': 'Fire hose reel'},
    r'\bFE\b': {'category': 'fire', 'description': 'Fire extinguisher'},
    r'\bSPR\b': {'category': 'fire', 'description': 'Sprinkler head'},
    r'\bMCP\b': {'category': 'fire', 'description': 'Manual call point'},
    r'\bFIP\b': {'category': 'fire', 'description': 'Fire indicator panel'},
    r'\bBAM\b': {'category': 'fire', 'description': 'Beam smoke detector'},
    # Structural
    r'\bC(\d{1,3})\b': {'category': 'structural', 'description': 'Column'},
    r'\bB(\d{1,3})\b': {'category': 'structural', 'description': 'Beam'},
    r'\bS(\d{1,3})\b': {'category': 'structural', 'description': 'Slab'},
    r'\bF(\d{1,3})\b': {'category': 'structural', 'description': 'Footing'},
    # Architectural
    r'\bD(\d{1,3})\b': {'category': 'architectural', 'description': 'Door'},
    r'\bW(\d{1,3})\b': {'category': 'architectural', 'description': 'Window'},
    # Mechanical / HVAC
    r'\bAC\b': {'category': 'mechanical', 'description': 'Air conditioning unit'},
    r'\bFCU\b': {'category': 'mechanical', 'description': 'Fan coil unit'},
    r'\bVAV\b': {'category': 'mechanical', 'description': 'Variable air volume'},
    r'\bAHU\b': {'category': 'mechanical', 'description': 'Air handling unit'},
}

# Dimension patterns: match things like "6000", "3500mm", "2.4m", "12'-6\""
DIMENSION_PATTERNS = [
    r'(\d{3,6})\s*(?:mm)?(?:\s|$)',        # 6000 or 6000mm (metric, no decimal)
    r'(\d+\.\d+)\s*m(?:\s|$)',              # 3.5m
    r'(\d+)\s*m(?:\s|$)',                   # 12m
    r"(\d+)['\u2019]-?\s*(\d+)[\"″]?",     # 12'-6" (imperial)
]

# Scale patterns in title blocks
SCALE_PATTERNS = [
    r'1\s*:\s*(\d+)',                        # 1:100, 1:50
    r'SCALE\s*[:=]?\s*1\s*:\s*(\d+)',        # SCALE: 1:100
    r'(\d+)\s*:\s*1',                        # 100:1 (less common)
]

# Category colors for annotation downstream
CATEGORY_COLORS = {
    'electrical': '#2196F3',    # Blue
    'plumbing': '#4CAF50',      # Green
    'fire': '#F44336',          # Red
    'structural': '#FF9800',    # Orange
    'architectural': '#9C27B0', # Purple
    'mechanical': '#00BCD4',    # Cyan
    'unknown': '#607D8B',       # Grey
}


def extract_text_objects(page):
    """Extract all text objects with positions from a PDF page."""
    text_objects = []
    blocks = page.get_text("dict", flags=fitz.TEXT_PRESERVE_WHITESPACE)["blocks"]

    for block in blocks:
        if block.get("type") != 0:  # text block
            continue
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                text = span.get("text", "").strip()
                if not text:
                    continue
                bbox = span.get("bbox", [0, 0, 0, 0])
                text_objects.append({
                    "text": text,
                    "x": round(bbox[0], 1),
                    "y": round(bbox[1], 1),
                    "x2": round(bbox[2], 1),
                    "y2": round(bbox[3], 1),
                    "cx": round((bbox[0] + bbox[2]) / 2, 1),
                    "cy": round((bbox[1] + bbox[3]) / 2, 1),
                    "font_size": round(span.get("size", 0), 1),
                    "font": span.get("font", ""),
                })
    return text_objects


def detect_tags(text_objects):
    """Match text objects against construction tag patterns. Returns tag instances with locations."""
    tag_instances = []  # individual occurrences with coordinates
    tag_counts = defaultdict(lambda: {"count": 0, "description": "", "category": "", "locations": []})

    for obj in text_objects:
        text = obj["text"]
        for pattern, info in TAG_PATTERNS.items():
            match = re.search(pattern, text)
            if match:
                tag_text = match.group(0)
                tag_instances.append({
                    "tag": tag_text,
                    "full_text": text,
                    "category": info["category"],
                    "description": info["description"],
                    "x": obj["x"],
                    "y": obj["y"],
                    "cx": obj["cx"],
                    "cy": obj["cy"],
                    "x2": obj["x2"],
                    "y2": obj["y2"],
                })
                entry = tag_counts[tag_text]
                entry["count"] += 1
                entry["description"] = info["description"]
                entry["category"] = info["category"]
                entry["locations"].append({
                    "x": obj["cx"],
                    "y": obj["cy"],
                })
                break  # Only match first pattern per text object

    # Convert locations lists for JSON serialization
    tag_counts_clean = {}
    for tag, data in tag_counts.items():
        tag_counts_clean[tag] = {
            "count": data["count"],
            "description": data["description"],
            "category": data["category"],
            "locations": data["locations"],
        }

    return tag_instances, tag_counts_clean


def detect_dimensions(text_objects):
    """Find dimension annotations in text objects."""
    dimensions = []
    for obj in text_objects:
        text = obj["text"]
        for pattern in DIMENSION_PATTERNS:
            match = re.search(pattern, text)
            if match:
                try:
                    if len(match.groups()) == 2:
                        # Imperial: feet and inches
                        feet = int(match.group(1))
                        inches = int(match.group(2))
                        value_mm = round((feet * 12 + inches) * 25.4, 1)
                    elif '.' in match.group(1):
                        # Decimal metres
                        value_mm = round(float(match.group(1)) * 1000, 1)
                    else:
                        val = int(match.group(1))
                        if val < 100:
                            # Likely metres
                            value_mm = val * 1000
                        else:
                            # Already mm
                            value_mm = val
                except (ValueError, IndexError):
                    continue

                dimensions.append({
                    "text": text.strip(),
                    "value_mm": value_mm,
                    "x": obj["cx"],
                    "y": obj["cy"],
                })
                break
    return dimensions


def detect_scale(text_objects, page_rect):
    """Try to detect the drawing scale from title block or annotations."""
    # Look for scale in text, preferring text near the bottom-right (title block area)
    page_h = page_rect.height
    page_w = page_rect.width

    candidates = []
    for obj in text_objects:
        for pattern in SCALE_PATTERNS:
            match = re.search(pattern, obj["text"], re.IGNORECASE)
            if match:
                try:
                    factor = int(match.group(1))
                    # Prefer title block area (bottom-right quadrant)
                    in_title_block = obj["cy"] > page_h * 0.7 and obj["cx"] > page_w * 0.5
                    candidates.append({
                        "factor": factor,
                        "text": obj["text"].strip(),
                        "x": obj["cx"],
                        "y": obj["cy"],
                        "in_title_block": in_title_block,
                    })
                except (ValueError, IndexError):
                    continue

    if not candidates:
        return {"detected": False}

    # Prefer title block matches
    title_block_matches = [c for c in candidates if c["in_title_block"]]
    best = title_block_matches[0] if title_block_matches else candidates[0]

    return {
        "detected": True,
        "factor": best["factor"],
        "method": "title_block" if best["in_title_block"] else "annotation",
        "confidence": "high" if best["in_title_block"] else "medium",
        "source_text": best["text"],
    }


def detect_title_block(text_objects, page_rect):
    """Extract title block info from bottom-right area of page."""
    page_h = page_rect.height
    page_w = page_rect.width

    # Title block is typically in the bottom-right
    tb_texts = [
        obj for obj in text_objects
        if obj["cy"] > page_h * 0.75 and obj["cx"] > page_w * 0.55
    ]

    # Sort by position (top to bottom, left to right)
    tb_texts.sort(key=lambda o: (o["cy"], o["cx"]))

    title_block = {
        "texts": [t["text"] for t in tb_texts[:20]],  # Cap at 20 items
    }

    # Try to identify drawing number and revision
    for obj in tb_texts:
        text = obj["text"]
        # Drawing number patterns
        dwg_match = re.search(r'(?:DWG|DRG|DRAWING)[\s.:#-]*([A-Z0-9][-A-Z0-9./]+)', text, re.IGNORECASE)
        if dwg_match:
            title_block["drawing_number"] = dwg_match.group(1)
        # Revision
        rev_match = re.search(r'(?:REV|REVISION)[\s.:#-]*([A-Z0-9]+)', text, re.IGNORECASE)
        if rev_match:
            title_block["revision"] = rev_match.group(1)

    return title_block


def extract_paths_summary(page):
    """Get a summary of vector paths (lines, curves) on the page."""
    drawings = page.get_drawings()
    line_count = 0
    rect_count = 0
    curve_count = 0
    total_items = len(drawings)

    for d in drawings:
        for item in d.get("items", []):
            kind = item[0]
            if kind == "l":
                line_count += 1
            elif kind == "re":
                rect_count += 1
            elif kind in ("c", "qu"):
                curve_count += 1

    return {
        "total_paths": total_items,
        "lines": line_count,
        "rectangles": rect_count,
        "curves": curve_count,
    }


def extract_page(page, page_num=1):
    """
    Full extraction pipeline for a single PDF page.

    Args:
        page: fitz.Page object
        page_num: 1-based page number (for metadata)

    Returns:
        dict with all extraction results
    """
    rect = page.rect
    text_objects = extract_text_objects(page)
    tag_instances, tag_counts = detect_tags(text_objects)
    dimensions = detect_dimensions(text_objects)
    scale = detect_scale(text_objects, rect)
    title_block = detect_title_block(text_objects, rect)
    paths = extract_paths_summary(page)

    return {
        "page_number": page_num,
        "page_size": {
            "width_pts": round(rect.width, 1),
            "height_pts": round(rect.height, 1),
            "width_mm": round(rect.width * 25.4 / 72, 1),
            "height_mm": round(rect.height * 25.4 / 72, 1),
        },
        "scale": scale,
        "title_block": title_block,
        "tag_counts": tag_counts,
        "tag_instances": tag_instances,
        "dimensions_found": dimensions,
        "text_objects": text_objects,
        "paths_summary": paths,
        "raw_stats": {
            "text_objects": len(text_objects),
            "tag_instances": len(tag_instances),
            "unique_tags": len(tag_counts),
            "dimensions": len(dimensions),
        },
        "category_colors": CATEGORY_COLORS,
    }


def extract_pdf(pdf_path, page_num=None, output_path=None, pretty=False):
    """Extract from a PDF file."""
    doc = fitz.open(pdf_path)

    if page_num:
        if page_num < 1 or page_num > len(doc):
            print(f"ERROR: Page {page_num} out of range (1-{len(doc)})", file=sys.stderr)
            sys.exit(1)
        pages_to_process = [page_num - 1]
    else:
        pages_to_process = list(range(len(doc)))

    results = []
    for idx in pages_to_process:
        page = doc[idx]
        result = extract_page(page, idx + 1)
        results.append(result)

    doc.close()

    output = results[0] if len(results) == 1 else {"pages": results}

    if output_path:
        with open(output_path, "w") as f:
            json.dump(output, f, indent=2 if pretty else None)
        print(f"Extraction saved to: {output_path}", file=sys.stderr)
    else:
        print(json.dumps(output, indent=2 if pretty else None))

    return output


def main():
    parser = argparse.ArgumentParser(description="Extract vector data from construction drawing PDF")
    parser.add_argument("pdf_path", help="Path to PDF file")
    parser.add_argument("-o", "--output", help="Output JSON file path")
    parser.add_argument("--page", type=int, help="Extract specific page (1-based)")
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON output")

    args = parser.parse_args()

    if not Path(args.pdf_path).exists():
        print(f"ERROR: File not found: {args.pdf_path}", file=sys.stderr)
        sys.exit(1)

    extract_pdf(args.pdf_path, page_num=args.page, output_path=args.output, pretty=args.pretty)


if __name__ == "__main__":
    main()
