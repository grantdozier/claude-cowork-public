#!/usr/bin/env python3
"""
PDF Splitter & Per-Page Extractor for Construction Drawings

Splits a multi-page PDF into individual page PDFs and images,
then runs vector extraction on each page separately.

This dramatically improves AI vision reliability — analysing one drawing
at a time instead of a merged 20-page document.

Usage:
    python split_and_extract.py drawing.pdf -o output_dir
    python split_and_extract.py drawing.pdf -o output_dir --dpi 200
    python split_and_extract.py drawing.pdf -o output_dir --pages 1,3,5
"""

import sys
import json
import os
import argparse
from pathlib import Path

try:
    import fitz  # PyMuPDF
except ImportError:
    print("ERROR: PyMuPDF required. Install with: pip install pymupdf", file=sys.stderr)
    sys.exit(1)

# Import the extraction module
SCRIPT_DIR = Path(__file__).parent
sys.path.insert(0, str(SCRIPT_DIR))
from extract import extract_page


def split_pdf(
    pdf_path: str,
    output_dir: str,
    dpi: int = 150,
    pages: list = None,
    render_images: bool = True,
) -> dict:
    """
    Split a multi-page PDF into individual pages.

    For each page produces:
      - A single-page PDF (for vector extraction downstream)
      - A PNG image (for individual AI vision analysis)
      - Vector extraction JSON (from extract.py)

    Args:
        pdf_path: Path to source PDF
        output_dir: Directory to write outputs
        dpi: Resolution for rendered page images (default 150, use 200+ for detail)
        pages: Optional list of 1-based page numbers to process. None = all.
        render_images: Whether to render PNG images (default True)

    Returns:
        Manifest dict with metadata and per-page file paths
    """
    doc = fitz.open(pdf_path)
    total_pages = len(doc)
    source_name = Path(pdf_path).stem

    os.makedirs(output_dir, exist_ok=True)

    # Determine which pages to process
    if pages:
        page_indices = [p - 1 for p in pages if 0 < p <= total_pages]
    else:
        page_indices = list(range(total_pages))

    manifest = {
        "source_file": Path(pdf_path).name,
        "total_pages": total_pages,
        "pages_processed": len(page_indices),
        "output_dir": str(output_dir),
        "dpi": dpi,
        "pages": [],
    }

    for idx in page_indices:
        page_num = idx + 1
        page = doc[idx]
        page_info = {
            "page_number": page_num,
            "files": {},
        }

        # --- 1. Single-page PDF ---
        single_pdf_path = os.path.join(output_dir, f"{source_name}_page{page_num}.pdf")
        single_doc = fitz.open()  # new empty document
        single_doc.insert_pdf(doc, from_page=idx, to_page=idx)
        single_doc.save(single_pdf_path)
        single_doc.close()
        page_info["files"]["pdf"] = single_pdf_path

        # --- 2. Page image (PNG) for vision analysis ---
        if render_images:
            img_path = os.path.join(output_dir, f"{source_name}_page{page_num}.png")
            zoom = dpi / 72  # 72 is default PDF DPI
            mat = fitz.Matrix(zoom, zoom)
            pix = page.get_pixmap(matrix=mat)
            pix.save(img_path)
            page_info["files"]["image"] = img_path
            page_info["image_size"] = {
                "width": pix.width,
                "height": pix.height,
            }

        # --- 3. Vector extraction ---
        extraction = extract_page(page, page_num)
        json_path = os.path.join(output_dir, f"{source_name}_page{page_num}_extraction.json")
        with open(json_path, "w") as f:
            json.dump(extraction, f, indent=2)
        page_info["files"]["extraction_json"] = json_path

        # Include key summary info in manifest
        page_info["scale"] = extraction.get("scale", {})
        page_info["title_block"] = extraction.get("title_block", {})
        page_info["tag_counts"] = extraction.get("tag_counts", {})
        page_info["stats"] = extraction.get("raw_stats", {})

        manifest["pages"].append(page_info)
        print(f"  Page {page_num}/{total_pages}: "
              f"{page_info['stats'].get('text_objects', 0)} text objects, "
              f"{len(page_info['tag_counts'])} tag types found",
              file=sys.stderr)

    doc.close()

    # Write manifest
    manifest_path = os.path.join(output_dir, "manifest.json")
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)
    manifest["manifest_path"] = manifest_path

    return manifest


def main():
    parser = argparse.ArgumentParser(
        description="Split construction PDF into individual pages for reliable analysis"
    )
    parser.add_argument("pdf_path", help="Path to multi-page PDF")
    parser.add_argument("-o", "--output-dir", required=True, help="Output directory")
    parser.add_argument("--dpi", type=int, default=150,
                        help="Image resolution (default 150, use 200+ for detailed drawings)")
    parser.add_argument("--pages", type=str, default=None,
                        help="Comma-separated page numbers to process (default: all)")
    parser.add_argument("--no-images", action="store_true",
                        help="Skip PNG image rendering (vector extraction only)")

    args = parser.parse_args()

    if not Path(args.pdf_path).exists():
        print(f"ERROR: File not found: {args.pdf_path}", file=sys.stderr)
        sys.exit(1)

    pages = None
    if args.pages:
        pages = [int(p.strip()) for p in args.pages.split(",")]

    print(f"Splitting: {args.pdf_path}", file=sys.stderr)
    manifest = split_pdf(
        args.pdf_path,
        args.output_dir,
        dpi=args.dpi,
        pages=pages,
        render_images=not args.no_images,
    )

    print(f"\nDone. Processed {manifest['pages_processed']} pages.", file=sys.stderr)
    print(f"Manifest: {manifest['manifest_path']}", file=sys.stderr)
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
