---
name: construction-takeoff
description: Extract quantities from construction drawings using vector data extraction combined with AI vision. Handles tag counting (light fittings, power outlets, fixtures), area/volume measurement (concrete, flooring), and linear measurement (cable trays, pipes). Use when user uploads construction drawings and needs quantity takeoffs. Automatically splits multi-page PDFs into individual drawings for page-by-page analysis to maximize accuracy. Extracts vector data programmatically first, then uses AI vision on each page individually to verify and supplement. Reliably measures primary quantities from vector data, then infers secondary quantities from those primary measurements. Produces a professional Excel register of all quantities with confidence ratings, methods, and notes.
---

# Construction Takeoff Skill

Extract quantities from construction drawings by combining programmatic vector extraction with AI vision analysis. Output a professional Excel quantity register.

## Core Principles

1. **Split first** — Always split multi-page PDFs into individual pages. Analysing one drawing at a time is dramatically more reliable than trying to process a merged 20-page document.

2. **Vector data is the foundation** — Extract text, coordinates, dimensions, and shapes programmatically from the PDF before any vision analysis. This gives precise, repeatable data that doesn't hallucinate.

3. **Vision verifies and supplements** — Use AI vision on individual page images to verify vector-extracted counts, identify unlabelled symbols, and understand spatial context that vector data alone can't provide.

4. **Primary → Secondary quantities** — Measure what can be reliably extracted (tag counts, dimensions, areas from vector data), then *infer* secondary quantities from those primary measurements. Don't try to measure everything directly.

5. **Excel register output** — The final deliverable is always a professionally formatted Excel (.xlsx) register with all quantities, confidence levels, methods, and assumptions clearly documented. No annotated images or visual markups are produced.

## Workflow

### Step 1: Split the PDF into Individual Pages

**This is the most important step for reliability.** A merged PDF with 20 drawings overwhelms vision analysis. Splitting gives each drawing its own focused analysis.

```bash
pip install pymupdf Pillow --break-system-packages
python /mnt/skills/user/construction-takeoff/scripts/split_and_extract.py /path/to/drawings.pdf -o /home/claude/takeoff_output --no-images
```

Note: Use `--no-images` flag since we don't need rendered PNGs for visual markup. We only need the vector extraction JSON data. If vision analysis is needed to verify counts, render images temporarily but do not include them in the output.

This produces for **each page**:
- A single-page PDF (for any downstream processing)
- A vector extraction JSON (text, tags, dimensions, paths, scale)
- A `manifest.json` summarising all pages

Options:
```bash
# Process only specific pages
python split_and_extract.py drawings.pdf -o output --pages 1,3,5
```

For a **single-page drawing**, you can use the extraction script directly:
```bash
python /mnt/skills/user/construction-takeoff/scripts/extract.py drawing.pdf --page 1 -o extracted.json --pretty
```

### Step 2: Review Vector Extraction Results (Per Page)

Read the manifest.json first for an overview, then review each page's extraction JSON. The vector extraction provides your **primary quantities** — these are the most reliable data.

**Check scale detection on each page** (different pages may have different scales):
```json
"scale": {
  "detected": true,
  "factor": 100,
  "method": "title_block",
  "confidence": "high"
}
```

**Check tag counts** (these are high-confidence primary quantities):
```json
"tag_counts": {
  "L1": {"count": 12, "description": "Light fitting", "category": "electrical", "locations": [{"x": 234.5, "y": 456.7}, ...]},
  "GPO": {"count": 24, "description": "General power outlet", "category": "electrical", "locations": [...]}
}
```

**Check dimensions found** (use to verify/derive scale):
```json
"dimensions_found": [
  {"text": "6000", "value_mm": 6000, "x": 234.5, "y": 456.7}
]
```

### Step 3: Analyse Each Drawing Individually

For each page:

1. **Review the vector extraction JSON** — this is your primary data source
2. **If needed, temporarily render a page image** for vision verification of ambiguous counts (but do NOT include images in output)
3. **Verify vector-extracted tag counts** against vision analysis where needed
4. **Identify unlabelled items** — symbols without text tags won't appear in extraction
5. **Understand layout context** — room names, zones, areas of work
6. **Check the legend** — symbol definitions may differ from standard patterns
7. **Identify measurement boundaries** — for area/volume calculations
8. **Note drawing type** — plan, elevation, section, detail (affects what quantities are relevant)

**Important**: Process pages one at a time. Complete the analysis of one drawing before moving to the next.

### Step 4: Primary and Secondary Quantity Inference

This is the key methodology for accurate takeoffs. Not everything needs to be (or can be) measured directly.

#### Primary Quantities (Direct Measurement — High Confidence)

These come from vector extraction and are reliably measurable:

| Quantity Type | Source | Confidence |
|--------------|--------|------------|
| Tagged item counts | Text extraction (tags like L1, GPO, WC) | High |
| Explicit dimensions | Dimension text in drawing (6000mm, 3.5m) | High |
| Scale factor | Title block or dimension matching | High/Medium |
| Room/area labels | Text extraction | High |
| Drawing number & revision | Title block text | High |

#### Secondary Quantities (Inferred — Medium Confidence)

Derive these from primary measurements rather than trying to measure directly:

| Secondary Quantity | Inferred From | Method |
|-------------------|---------------|--------|
| Floor areas (m²) | Room dimensions from vector data | Length × Width from extracted dimensions |
| Concrete volumes (m³) | Area × standard thickness | e.g., 303m² slab × 0.15m = 45.5m³ |
| Paint areas (m²) | Room perimeter × ceiling height | Perimeter from dimensions, assume 2.7m height unless noted |
| Cable lengths (m) | Outlet counts × average run | e.g., 24 GPOs × 8m avg run = 192m cable |
| Pipe lengths (m) | Fixture counts × typical distances | e.g., 6 WCs × 4m avg run |
| Formwork (m²) | Concrete element dimensions | Perimeter × depth for beams/footings |
| Excavation (m³) | Footing dimensions + working space | Footing volume × 1.5 for batters |
| Conduit (m) | Number of circuits × avg distance to DB | From light/power counts |
| Ceiling area (m²) | Floor area (often 1:1) | Subtract stairwells, voids |
| Skirting/cornice (m) | Room perimeters | Perimeter minus door widths |

#### Approach for Each Drawing

1. **Extract all primary quantities** from vector data first
2. **Verify primary quantities** with vision analysis if needed
3. **Calculate secondary quantities** using formulas and industry assumptions
4. **Flag assumptions** — always note what was measured vs. inferred and what assumptions were used
5. **Apply waste factors** where appropriate

### Step 5: Combine Results Across Pages

After processing all pages individually, merge results being careful about:
- **Duplicates across pages** — a fixture shown on both the floor plan and the reflected ceiling plan is ONE fixture, not two
- **Different scales** — page 1 might be 1:100, page 3 might be 1:50
- **Drawing types** — a plan view and a section view of the same area show the same items from different perspectives
- **Schedules vs plans** — if a door schedule says 15 doors and the plan shows 15 door tags, count them once

### Step 6: Output Excel Register

**The final output is always a professionally formatted .xlsx file.** Use the xlsx skill best practices (read `/mnt/skills/public/xlsx/SKILL.md` for formatting guidance).

Generate the Excel register using openpyxl with the following structure:

#### Required Sheets

**Sheet 1: "Quantity Register"** (main takeoff)

| Column | Content | Notes |
|--------|---------|-------|
| A | Item No | Sequential numbering (1, 2, 3...) |
| B | Tag | Tag code from drawing (L1, GPO, WC, etc.) |
| C | Description | Full description of item |
| D | Trade / Category | Electrical, Plumbing, Fire, Structural, Architectural, Mechanical |
| E | Quantity | Numeric value |
| F | Unit | EA, m², m³, m, LM, etc. |
| G | Drawing / Page | Source drawing number or page reference |
| H | Confidence | High, Medium, Low |
| I | Method | text_extraction, vector_extraction, dimension_calc, inferred, vision_count |
| J | Assumptions / Notes | Explain inference logic, waste factors, assumptions used |

**Sheet 2: "Summary by Trade"** (pivot summary)

Grouped totals by Trade/Category with subtotals per item type. Use Excel formulas (SUMIFS, COUNTIFS) referencing Sheet 1 data so the summary updates automatically.

**Sheet 3: "Drawing Index"** (optional, for multi-page sets)

List of all drawings processed with page number, drawing number, title, scale, and what was extracted from each.

#### Formatting Requirements

- **Header row**: Bold, dark background (RGB: 44, 62, 80), white text, frozen panes
- **Trade colour coding** in column D cells (background fill):
  - Electrical = Light blue (RGB: 214, 234, 248)
  - Plumbing = Light green (RGB: 212, 239, 223)
  - Fire = Light red (RGB: 245, 215, 215)
  - Structural = Light orange (RGB: 250, 229, 211)
  - Architectural = Light purple (RGB: 230, 224, 239)
  - Mechanical = Light cyan (RGB: 212, 244, 244)
- **Confidence colour coding** in column H:
  - High = Green text
  - Medium = Orange text
  - Low = Red text
- **Auto-filter** on all columns
- **Column widths** auto-fitted to content
- **Number formatting**: quantities to appropriate decimal places
- **Borders**: thin borders on all data cells

#### Excel Generation Code Pattern

```python
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Quantity Register"

# Headers
headers = ["Item No", "Tag", "Description", "Trade / Category", "Quantity", "Unit", "Drawing / Page", "Confidence", "Method", "Assumptions / Notes"]
header_font = Font(bold=True, color="FFFFFF", name="Arial", size=10)
header_fill = PatternFill("solid", fgColor="2C3E50")

for col, header in enumerate(headers, 1):
    cell = ws.cell(row=1, column=col, value=header)
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = Alignment(horizontal="center", vertical="center")

# Freeze header row
ws.freeze_panes = "A2"

# Auto-filter
ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}1"

# ... populate data rows ...

# Auto-fit column widths
for col in range(1, len(headers) + 1):
    max_length = max(len(str(ws.cell(row=r, column=col).value or "")) for r in range(1, ws.max_row + 1))
    ws.column_dimensions[get_column_letter(col)].width = min(max_length + 2, 40)

wb.save("/home/claude/takeoff_register.xlsx")
```

After saving, copy to outputs:
```bash
cp /home/claude/takeoff_register.xlsx /mnt/user-data/outputs/takeoff_register.xlsx
```

**Always present the Excel file to the user** using `present_files`.

## Tag Recognition

The extraction script recognises common Australian/international construction tags:

### Electrical
`L1-L99` Light fittings | `LD` LED downlight | `GPO` Power outlet | `DB` Distribution board | `SW` Switch | `EX` Exit light | `EM` Emergency light | `SD` Smoke detector | `FAN/EF` Exhaust fan

### Plumbing
`WC` Toilet | `WHB` Wall hung basin | `SHR` Shower | `SK` Sink | `FL/FD` Floor drain | `HW` Hot water

### Fire Services
`FH/FHR` Fire hose reel | `FE` Fire extinguisher | `SPR` Sprinkler | `MCP` Manual call point

### Structural
`C1-C99` Columns | `B1-B99` Beams | `S1-S99` Slabs | `F1-F99` Footings

### Architectural
`D1-D99` Doors | `W1-W99` Windows

See `references/tags_and_symbols.md` for the complete list.

## Measurement Calculations

### With Scale Factor

If scale is detected (e.g., 1:100), measurements convert automatically:
```
real_mm = drawing_pts × (25.4/72) × scale_factor
```

### Without Scale Factor

If scale isn't detected:
1. Find a known dimension on the drawing (e.g., door width 820mm)
2. Measure the same element in the extraction data (in points)
3. Calculate: `scale = known_mm / (measured_pts × 0.353)`
4. Apply to other measurements

### Volume from Area
```
Volume (m³) = Area (m²) × Thickness (m)
```

Common thicknesses: ground slab 150-200mm, suspended slab 150-250mm, footings 300-600mm.

## Waste Factors

Apply after calculating net quantities:
- Electrical cable: 5-10%
- Flooring: 5-10%
- Concrete: 2-5%
- Paint: 10-15%
- Plasterboard: 10%
- Tiles: 10-15% (more for diagonal layouts)

## Common Pitfalls

- **Not splitting the PDF** — Analysing a 20-page merged PDF as one document drastically reduces accuracy. Always split first.
- **Trusting vision over vector data** — Vector-extracted tag counts are more reliable than trying to count symbols visually. Use vision to verify, not as the primary source.
- **Double counting across pages** — The same item shown on a plan, section, and detail is one item.
- **Missing scale differences** — Different pages may have different scales. Check each page.
- **Legend items counted as real items** — Tags in the legend are definitions, not actual items. The extraction may count them. Review and deduct legend occurrences from counts.
- **Measuring what should be inferred** — Don't try to trace every cable run visually. Count the outlets (primary) and calculate cable from that (secondary).

## Scripts Reference

### split_and_extract.py (Preferred for multi-page PDFs)
```bash
# Split all pages, extract vector data only (no images)
python split_and_extract.py drawings.pdf -o output_dir --no-images

# Specific pages only
python split_and_extract.py drawings.pdf -o output_dir --pages 1,3,5 --no-images

# With images for temporary vision verification (don't include in output)
python split_and_extract.py drawings.pdf -o output_dir --dpi 150
```

### extract.py (Single page or quick extraction)
```bash
python extract.py drawing.pdf -o extracted.json --pretty
python extract.py drawing.pdf --page 1 -o page1.json
```

## Example Prompts

**Multi-page drawing set:**
> I've uploaded a 15-page drawing set. Extract quantities from the electrical drawings and give me an Excel register.

**Tag counting:**
> Extract quantities from this electrical drawing and produce a quantity register with confidence levels.

**Area measurement with inference:**
> Calculate floor areas for tiling from this architectural plan. Extract dimensions from vector data, calculate areas, then infer grout quantities and tile counts. Output as Excel.

**Full takeoff with secondary quantities:**
> Full quantity takeoff for this hydraulic drawing — count all fixtures from vector data, then infer pipe runs, copper quantities, and drainage from the fixture counts. Give me the Excel register.
